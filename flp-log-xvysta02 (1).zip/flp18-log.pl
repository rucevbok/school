% Autor: Jaroslav Vystavěl
% Login: xvysta02
% Název projektu: Kostra grafu
% Předmět: FLP (Logický projekt)
%
% Tento kód vznikl jako studentský projekt na FIT VUT v Brně.

% načítání vstupu
read_line(L,C) :-
  get_char(C),
  (isEOFEOL(C), L = [], !;
    read_line(LL,_),% atom_codes(C,[Cd]),
    [C|LL] = L).

%Tests if character is EOF or LF.
isEOFEOL(C) :-
  C == end_of_file;
  (char_code(C,Code), Code==10).

read_lines(Ls) :-
  read_line(L,C),
  ( C == end_of_file, Ls = [] ;
    read_lines(LLs), Ls = [L|LLs]
  ).

% rozdeli radek na podseznamy
split_line([],[[]]) :- !.
split_line([' '|T], [[]|S1]) :- !, split_line(T,S1).
split_line([32|T], [[]|S1]) :- !, split_line(T,S1).    % aby to fungovalo i s retezcem na miste seznamu
split_line([H|T], [[H|G]|S1]) :- split_line(T,[G|S1]). % G je prvni seznam ze seznamu seznamu G|S1

% vstupem je seznam řádků (každý řádek je seznam znaků)
split_lines([],[]).
split_lines([L|Ls],[H|T]) :- split_lines(Ls,T), split_line(L,H).


% funkce, která namapuje downcase_atom/2 na každý prvek v poli (převod na malá písmena)
downcase_list(AnyCaseList, DownCaseList)  :-
  maplist(downcase_atom, AnyCaseList, DownCaseList).

% úprava seznamu do požadovaného tvaru A-B
lists_pairs([],[]).                       
lists_pairs([A,B|Ls],[A-B|Ps]) :-    
   lists_pairs(Ls,Ps).


% vstupní predikát
start :-
    prompt(_, ''),
    read_lines(LL),
    split_lines(LL,S),
    flatten(S,Res),
    downcase_list(Res, Out),
    lists_pairs(Out,My),
    solution1(My),
    halt.


% pracuji s neorientovaným grafem, proto musím vyzkoušet obě možnosti
edge(A-B,[A-B|G]).
edge(B-A,[A-B|G]).
edge(A-B,[_|G]) :- 
    edge(A-B,G). 


% nejprve najde všechna řešení solution/2, setřídí je (čímž ostraní duplikáty), 
% vybere ty grafy, které pokrývají vstupní graf. Nakonec zavolá predikát pro výpis

solution1(G) :- findall(X,solution(G,X),Xs), sort(Xs,R), graph_covers(G, R, Out), write_ListOfLists(Out). 

% poznámka: z nějakého důvodu mi nefungoval vstup/výstup v případě, že byl ve tvaru velkých písmen
%           Byl jsem tedy nucen převést vstup na minuskule a poté opět zpět. 
%           (string_upper/2 není dostupný na Merlinovi, jinak by nebyla funkce divideIt/1 zapotřebí)

% suplování string_upper/2, vezme postupně A a B, převede do podoby velkého písmene a vytiskne
divideIt(A-B) :-
    upcase_atom(A,Acko),
    write(Acko),
    write('-'),
    upcase_atom(B,Becko),
    write(Becko).

% hlavní predikát výpisu
write_ListOfLists([]).
write_ListOfLists([H|T]) :-
    write_list(H),nl,write_ListOfLists(T).

% dostává postupně seznamy (jsou to řádky výstupu)
write_list([]).
write_list([H|T]) :-
    divideIt(H),
    write(' '),
    write_list(T).

% pokrytí grafu - bere postupně kandidáty na kostru, pokud uspějí, vloží je do výstupního seznamu
graph_covers(_Graph, [], []).
graph_covers(Graph, [Nodes|NodesRest], Covers) :-
    (   isItCov(Graph, Nodes)
    ->  Covers = [Nodes|CoversRest]
    ;   Covers = CoversRest),
    graph_covers(Graph, NodesRest, CoversRest).

% test zda se všechny vrcholy původního grafu vyskytují v testovaném grafu 
isItCov([],H).
isItCov([A-B|R],H) :-
    vertex(A,H),
    vertex(B,H), 
    isItCov(R,H). 

% ověření zda daná hrana je napojená na jinou hranu v grafu zadaném jako druhý parametr
vertex(A,[]) :- fail.   % prazdný graf - nesmysl
vertex(A,[A-_|G]).
vertex(A,[_-A|G]).
vertex(A,[_|G]) :- 
    vertex(A,G).

% ověřování konektivity grafu, kontrola zda na sebe jednotlivé části navazují
isItConnected([_|[]]).
isItConnected([A-B|T]) :- 
    vertex(A,T), isItConnected(T).
isItConnected([A-B|T]) :- 
    vertex(B,T), isItConnected(T).  

% nejprve vygeneruji všechny permutaci vstupní posloupnosti (resp. permutace všech suffixů listu)
% poté zkontroluji zda v grafu neexistuje kružnice a ověřím konektivitu
% takto přefiltrované grafy seřadím
solution(G, Out) :- returnPerms(G, T), not(doesItLoop(T)), isItConnected(T), sort(T,Out).

% kružnice existuje, pokud mezi dvema vrcholy A,B a tyto dva vrcholy zároveň tvoří hranu
doesItLoop(T) :- 
    tour(A, B,[A, M, N|P], T ), 
    edge(A-B, T).

% hleda cestu mezi A a B, postupně se snaží napojovat nové vrcholy, které ještě nejsou v cestě   
tour(A, B, P, T) :- 
    temp(A, .(B,[]), P, T).

temp(A, [A|P], [A|P], T).
temp(A, [C|P2], P, T) :- 
    (edge(B-C, T);
    edge(C-B, T)), 
    not(member(B, P2)),  % podiva se jestli B uz neni v ceste aby nevznikla kruznice
    temp(A, [B, C|P2], P, T). 

% tvorba permutací, rozbití seznamu na části a jejich vygenerování
returnPerms(Input, Res) :- 
    breakIt(Input,_,Lst),    
    perm(Lst,Res).

skip(H,[H|T],T).
skip(A,[H|L],[H|R]) :- 
    skip(A,L,R).

perm([], []) :- !.
perm(A, [H|T]) :- 
    skip(H, A, D),
    perm(D, T).

breakIt([], [], []).
breakIt([H|T],[H|L],R) :- 
    breakIt(T,L,R).
breakIt([H|T],L,[H|R]) :- 
    breakIt(T,L,R).







