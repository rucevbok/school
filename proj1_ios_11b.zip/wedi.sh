#!/bin/bash
### Jaroslav Vystavel ###
### wedi ###

# nastavovani promennych
most_modified=0
all_modified=0
before=0
after=0
jmeno_souboru=0
directory_or_file=0
date=0
file=0
hledany=0
directory=0

#export EDITOR=/usr/bin/vim
 

###########################
##  PARSOVANI ARGUMENTU  ##
###########################
 

while getopts ":mlb:a:" opt; do
        case    $opt    in
                m)              most_modified=1 directory_or_file=$OPTARG;;
                l)              all_modified=1;;
                b)              before=1 date=$OPTARG;;
                a)              after=1 date=$OPTARG;;
                *)              echo "Invalid option: -$OPTARG" >&2; exit 1;;
        esac
done


if [[ -z $EDITOR ]]; then
        echo "EDITOR neni nastaven"
        if [[ -z $VISUAL ]]; then
            exit 1
        fi

        EDITOR=$VISUAL
        
fi

   if [[ ! -e $WEDI_RC ]]; then
           #echo "Neni nastaven soubor, nastavuji vlastní"
           touch WEDI_RC     
           WEDI_RC=$(pwd)/WEDI_RC
           chmod u+x WEDI_RC
          # export WEDI_RC
  fi
        


# checking for errors in arguments
if [[ $before -eq 1 && $after -eq 1 ]]; then
        echo "Nemuze byt nastavena zaroven -b i -a"
        exit 1
fi
 
# if before or after is set
if [[ $before -eq 1 || $after -eq 1 ]]; then
        ((OPTIND--))
        shift $OPTIND
        directory_or_file=$*
else # shifting args
        ((OPTIND--))
        shift $OPTIND
        directory_or_file=$*
fi


 
# determine if passed arg is a file or a directory
if [[ -d $directory_or_file ]]; then
    #echo "$directory_or_file is a directory"
    directory=$directory_or_file
elif [[ -f $directory_or_file ]]; then
    #echo "$directory_or_file is a file"
    file=$directory_or_file
fi
 
# if there is no file or directory specified, get the current working directory (cwd)
if [[ $directory_or_file == "" ]]; then
         directory_or_file=$(cd -P -- "$(dirname -- "$0")" && pwd -P)

#         #VYRESIT PROC V TOMTO PRIPADE directory_or_file NEPRIDAVA SLASH NA KONCI !
         directory_or_file=$directory_or_file/
  
 fi
 
##########################
## HLAVNI FUNKCIONALITA ##
##########################
 
# nejcasteji upravovany
if [[ $most_modified -eq 1 ]]; then
        #echo "echo most modified filename of $directory_or_file"
      if  [[ "$directory_or_file" != /* ]]; then
    directory_or_file=$(pwd)/$directory_or_file/
    
fi
 if  [[ "$directory_or_file" != */ ]]; then
        directory_or_file=$directory_or_file/
        fi

 awk -F'|' -v tgt="$directory_or_file" '
    $2==tgt { max=(++cnt[$1] > max ? cnt[$1] : max) }
    END { for (file in cnt) if (cnt[file]==max) {print file;exit} }
' $WEDI_RC


        exit 0
fi
 
# seznam upravenych
if [[ $all_modified -eq 1 ]]; then
   
 
        #echo "echo all modified filenames of $directory_or_file"
        if  [[ "$directory_or_file" != /* ]]; then
        directory_or_file=$(pwd)/$directory_or_file/
        fi
        if  [[ "$directory_or_file" != */ ]]; then
        directory_or_file=$directory_or_file/
        fi
            #echo "v -l : "$directory_or_file
        
         awk -F"|" -v tgt="$directory_or_file"  '{
if($2==tgt)
    print $1;

 }' $WEDI_RC |sort|uniq


        #exit 0
fi
 
# upraveny pred datem
if [[ $before -eq 1 ]]; then

     if  [[ "$directory_or_file" != /* ]]; then
     directory_or_file=$(pwd)/$directory_or_file/
    fi


        awk -v date="$date" -F'|' '
        $2 -eq "$directory_or_file" {
            gsub(/-/, "", $3)
            gsub(/-/, "", date)
            if ($3<date && !a[$1]++)
                print $1
        }' $WEDI_RC
        #exit 0
fi
 
# upraveny po datumu
if [[ $after -eq 1 ]]; then
    if  [[ "$directory_or_file" != /* ]]; then
    directory_or_file=$(pwd)/$directory_or_file/

    fi
       
      #  echo $date
       # echo "echo all modified in $directory_or_file filenames after the date $date"
      
     
        awk -v date="$date" -F'|' '
        $2 -eq "$directory_or_file" {
            gsub(/-/, "", $3)
            gsub(/-/, "", date)
            if ($3>date && !a[$1]++)
                print $1
        }' $WEDI_RC

        #exit 0
fi

    # zjistuji zda se jedna o soubor, o slozku
if [[ $most_modified -eq 0  && $all_modified -eq 0 && $before -eq 0 && $after -eq 0 ]]; then 
    #echo "$directory_or_file"

    if [[ -d $directory_or_file ]]; then
        if  [[ "$directory_or_file" != /* ]]; then
        directory_or_file=$(pwd)/$directory_or_file/
        fi
        
        hledany=$(awk -F '|' '$2 eq "$directory_or_file" { f=$1 }END { print f }' $WEDI_RC)
        #echo $hledany
        if [[ $hledany == "" ]]; then
            exit 1
        fi

        echo -n "$hledany"  >> "$WEDI_RC"  
        echo -n "|">> "$WEDI_RC"  
        slozka=${directory_or_file%/*}/
        echo -n "$slozka" >> "$WEDI_RC"
        echo -n "|">>"$WEDI_RC"
        date "+%Y-%m-%d">> "$WEDI_RC"

        $EDITOR $directory_or_file/$hledany

    elif [[ -f $directory_or_file ]]; then
        if  [[ "$directory_or_file" != /* ]]; then

        directory_or_file=$(pwd)/$directory_or_file
        fi
          
        jmeno_souboru=${directory_or_file##*/}
        echo -n "$jmeno_souboru"  >> "$WEDI_RC"  
        echo -n "|">> "$WEDI_RC"  
        slozka=${directory_or_file%/*}/
        echo -n "$slozka" >> "$WEDI_RC"
        echo -n "|">>"$WEDI_RC"
        date "+%Y-%m-%d">> "$WEDI_RC"
        $EDITOR $directory_or_file
    else
        #novy soubor
       
         if  [[ "$directory_or_file" != /* ]]; then
        directory_or_file=$(pwd)/$directory_or_file

        fi
      
        
        jmeno_souboru=${directory_or_file##*/}
        slozka=${directory_or_file%/*}/
        echo $slozka
        if [[ ! -d $slozka ]]; then
            echo "Byla zadána neplatná složka."
            exit 1
        fi
        echo -n "$jmeno_souboru"  >> "$WEDI_RC"  
        echo -n "|">> "$WEDI_RC"  

        echo -n "$slozka" >> "$WEDI_RC"
        echo -n "|">>"$WEDI_RC"
        date "+%Y-%m-%d">> "$WEDI_RC"
        $EDITOR $directory_or_file
    fi
    exit 0
fi

exit 0



 










