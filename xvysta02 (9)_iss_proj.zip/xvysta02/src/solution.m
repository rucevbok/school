%JAROSLAV VYSTAVEL
%ISS Projekt
%xvysta02
%_____________________________

obrazek=imread('xvysta02.bmp');  
%krok1
H = [-0.5 -0.5 -0.5;-0.5 5 -0.5; -0.5 -0.5 -0.5];
krok1 = imfilter(obrazek,H);
imwrite(krok1, 'step1.bmp');

%krok2
for (x=1:512)
  for (y=1:512)
    krok2(x,y) = krok1(x,513-y);
  end;
end
imwrite(krok2, 'step2.bmp');

%krok3
krok3 = medfilt2(krok2, [5 5]);
imwrite(krok3, 'step3.bmp');

%krok4
H = [1 1 1 1 1; 
     1 3 3 3 1; 
     1 3 9 3 1; 
     1 3 3 3 1; 
     1 1 1 1 1]/49;
krok4 = imfilter(krok3,H);
imwrite(krok4, 'step4.bmp');


 
for(x=1:512)
  for(y=1:512)
    step4rot(x,y)=krok4(x,513-y);
  end;
end

chyba = 0;
step4er = double(step4rot);
step0er = double(obrazek);
for (x=1:512)
  for (y=1:512)
    chyba=chyba+double(abs(step0er(x,y)-step4er(x,y)));
  end;
end

chyba = chyba/512/512;

soubor = fopen('reseni.txt', 'w');
fprintf(soubor,'chyba=%.4f\n',chyba);


%krok5

Pocet=zeros(256);
min = double(krok4(x,y));
max = double(krok4(x,y));
for (x=1:512)
  for (y=1:512)
    if (double(krok4(x,y)) < min)
      min = double(krok4(x,y));
    end;
    if (double(krok4(x,y)) > max)
      max = double(krok4(x,y));
    end;
  end;
end;
min = min/255;
max = max/255;
krok5 = imadjust(krok4, [min max], [0 1]);
imwrite(krok5, 'step5.bmp');
mean_no_hist = mean2(double(krok4));
std_no_hist = std2(double(krok4));
mean_hist = mean2(double(krok5));
std_hist = std2(double(krok5));
fprintf(soubor,'mean_no_hist=%.4f\r\n',mean_no_hist);
fprintf(soubor,'std_no_hist=%.4f\r\n',std_no_hist);
fprintf(soubor,'mean_hist=%.4f\r\n',mean_hist);
fprintf(soubor,'std_hist=%.4f\r\n',std_hist);
fclose(soubor);

%krok6
N=2;
a=0;
b=255;

krok6=zeros(512,512);
for k=1:512
   for l=1:512      
      krok6(k,l) = round(((2^N)-1)*(double(krok5(k,l))-a)/(b-a))*(b-a)/((2^N)-1) + a;
   end
end
krok6=uint8(krok6);
imwrite(krok6, 'step6.bmp');


