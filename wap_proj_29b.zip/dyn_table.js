function dyn(idecko){


var xr = document.getElementById(String(idecko)).getElementsByTagName("th");
var i;
for (i = 0; i < xr.length; i++) {
    xr[i].setAttribute("draggable", "true");
}

var dragSrc;
var pk;
Array.prototype.forEach.call(
//Array.from(document.querySelector("thead").rows[0].cells).forEach(x => 
document.getElementById(String(idecko)).querySelector("thead").rows[0].cells,
function(x)
{
    x.addEventListener("dragstart", function(e) {
    const {target} = e;
    target.classList.add("drag");
    pk = target;
    //alert(pk.innerHTML);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", target.cellIndex);
    

});

    x.addEventListener("dragover", function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
});

    x.addEventListener("dragleave", function (e) {
    const {target} = e;
    target.classList.remove("over");
});

    x.addEventListener("dragenter", function(e) {
    const {target} = e;
    target.classList.add("over");
});
    x.addEventListener("dragend", function (e) {
    const {target} = e;
    target.classList.remove("drag");
    const headers = Array.from(document.getElementById(String(idecko)).querySelector("thead").rows[0].cells);
    headers.forEach(x => x.classList.remove("over"));
});
    x.addEventListener("drop", function(e) {
    const {target} = e;
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    // SWAP
        // const headers = Array.from(document.getElementById(String(idecko)).querySelector("thead").rows[0].cells);
        // const targetCellIndex = target.cellIndex;
        // const puvodni = pk.cellIndex;
        // const cellIndex = e.dataTransfer.getData("text/plain");

        // var temp = headers[targetCellIndex].innerHTML;
        // headers[targetCellIndex].innerHTML = headers[cellIndex].innerHTML;
        // headers[cellIndex].innerHTML = temp;
        // Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
        //     //.insertAdjacentElement('afterend', x.cells[cellIndex]);
        //     var temp = x.cells[targetCellIndex].innerHTML;
        //     x.cells[targetCellIndex].innerHTML = x.cells[cellIndex].innerHTML;
        //     x.cells[cellIndex].innerHTML = temp;
        // })
    // KONEC SWAP

    // POSUN SLOUPCU
    if (!target.isSameNode(pk)) {
        headers = Array.from(document.getElementById(String(idecko)).querySelector("thead").rows[0].cells);
        //alert(target.cellIndex);
       
        const targetCellIndex = target.cellIndex;
        const cellIndex = e.dataTransfer.getData("text/plain");
        var tmpe;
        var sum = 0;
        var th_cnt = document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount;
        var td_cnt = document.getElementById(String(idecko)).querySelector("tbody").querySelector("td").childElementCount;
        
        //alert("delka zahlavi: "+document.querySelector("thead").querySelector("tr").childElementCount);
        for(var o = 0; o < document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount; o++)
        {
           // alert("iterace: "+o+"aktual"+document.querySelector("thead").rows[0].cells[o].colSpan);
            sum = sum + document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[o].colSpan;
        }

        // je mezi dvema columnama nejakej colspan?
        //alert("targetCellIndex: "+targetCellIndex+" cellIndex: "+cellIndex);
       //alert("targetCellIndex - cellIndex: " + (targetCellIndex-cellIndex));
        var soucet=0;
        for(var t = cellIndex; t<= targetCellIndex; t++)
        {
           // alert("l");
            soucet = soucet + document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[t].colSpan;

        }
        pocet_predch_colspanu = 0;
        for(var t = 0; t< Math.max(cellIndex,targetCellIndex); t++)
        {
           // alert("l");
            pocet_predch_colspanu = pocet_predch_colspanu + (document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[t].colSpan-1);

        }
        //alert("pocet_predch_colspanu: "+pocet_predch_colspanu);
        //alert("A soucet: "+soucet);
        // podil rika jestli je mezi src a target columnem nejakej colspan, pokud neni, je roven hodnote 1
        var podil = (soucet/(targetCellIndex-cellIndex+1))
        //alert("podil: "+ podil);

        // _______________________________________
        var rozdil = sum - th_cnt;
       // alert("rozdil: "+ rozdil);
        tmpe = parseInt(cellIndex) + sum - th_cnt;
        tmpe2 = parseInt(targetCellIndex) + sum - th_cnt;
        //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
        //alert("tmpe: "+tmpe+" d "+(parseInt(cellIndex)+1));
       // alert("sum je: "+sum);
       // alert(document.querySelector("thead").rows[0].cells[cellIndex].colSpan);
        var bound = document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[cellIndex].colSpan;
        var target_bound = document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex].colSpan;
        var iter;
        //alert(cellIndex+ "_"+ targetCellIndex);
        //     0     <       1
        //     1     <       2
       // alert(" prvni: "+(tmpe2)+" druhy: "+tmpe);
        if(cellIndex < targetCellIndex)
        {
            if (bound == 1)
            {
                //alert("zui");

                headers[targetCellIndex].insertAdjacentElement('afterend', headers[cellIndex]);
                
                Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
            
                if(podil == 1 && rozdil == 0)
                {
                    //alert("trivialni tabulka");
                    x.cells[targetCellIndex].insertAdjacentElement('afterend', x.cells[cellIndex]);
                }
                else if(podil == 1 && rozdil == 1)
                {

                   //alert("Da1");
                    x.cells[targetCellIndex+pocet_predch_colspanu].insertAdjacentElement('afterend', x.cells[parseInt(cellIndex)+pocet_predch_colspanu]);
                }

                else
                {
                    //alert("co tady dela "+tmpe2+ "druhy: "+tmpe);
                    //alert(" prvni: "+(targetCellIndex)+" druhy: "+(targetCellIndex+pocet_predch_colspanu));
                    x.cells[tmpe2].insertAdjacentElement('afterend', x.cells[tmpe-1]);
                    //x.cells[targetCellIndex+pocet_predch_colspanu].insertAdjacentElement('afterend', x.cells[parseInt(cellIndex)+pocet_predch_colspanu]);
                } 
                });
             //   delej(idecko);
            }
            else 
            {
                //alert("ops");

                headers[targetCellIndex].insertAdjacentElement('afterend', headers[cellIndex]);
                Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{

                x.cells[targetCellIndex+rozdil].insertAdjacentElement('afterend', x.cells[cellIndex]);
                })

                Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{

                x.cells[targetCellIndex+rozdil].insertAdjacentElement('afterend', x.cells[cellIndex]);
             })
             //   delej(idecko);
            }
        } 
        else if (cellIndex > targetCellIndex)
        {
            var new_cell_index = (document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex].colSpan)+parseInt(cellIndex);
            //alert("new_cell_index: "+new_cell_index);
            var celkem_spanu = 0;
            for(var u = 0; u <= targetCellIndex; u++)
            {
                celkem_spanu = celkem_spanu + document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[u].colSpan;
            }
            //alert("celkem_spanu: "+(celkem_spanu-1));
            //alert("target: "+targetCellIndex);
            //var new_cell_targetIndex = celkem_spanu
            if (bound == 1)
            {
                //alert("tu");
                 //Array.from(document.getElementById(String(idecko)).querySelector("thead").rows[0]
                //headers[targetCellIndex].insertAdjacentElement('beforebegin', headers[cellIndex]);

                document.getElementById(String(idecko)).querySelector("thead").rows[0].insertBefore(headers[cellIndex],headers[targetCellIndex]);
                if(podil == 1)
                {
                    //alert("a tu");
                    Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                    x.cells[targetCellIndex].insertAdjacentElement('beforebegin', x.cells[cellIndex]);
                     });
                }
                else
                {
                    //alert("a tady");
                    if(rozdil == 0)
                    {
                      //alert("TRIVIALNI, NECHAT BYT");
                      Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                      //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
                      x.cells[tmpe2].insertAdjacentElement('beforebegin', x.cells[tmpe]);
                       });
                    }
                    else if (rozdil == 1 && pocet_predch_colspanu != 0 && soucet == 0 && document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex+1].colSpan == 1) 
                    {
                      //alert("targetCellIndexspan  "+document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex+1].colSpan);
                      Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                      //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
                      x.cells[celkem_spanu-1].insertAdjacentElement('beforebegin', x.cells[new_cell_index]);
                       });

                    }
                    else if(document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex+1].colSpan > 1)
                    {
                      //alert("kone: "+document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[targetCellIndex].colSpan > 1);
                      Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                      //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
                      x.cells[targetCellIndex].insertAdjacentElement('beforebegin', x.cells[tmpe]);
                       }); 
                    }
                    else if (pocet_predch_colspanu == 0)
                    {
                      //alert("ahoj");
                      Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                      //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
                      x.cells[targetCellIndex].insertAdjacentElement('beforebegin', x.cells[parseInt(cellIndex)]);
                       });                      
                    }
                    else if (pocet_predch_colspanu!=0 && soucet == 0){
                      //alert("ajhojd");
                      Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                      //alert("tmpe2: "+(tmpe2-1)+" tmpe: "+(tmpe-1));
                      x.cells[tmpe2].insertAdjacentElement('beforebegin', x.cells[tmpe]);
                       });  
                    }

                    //x.insertBefore(x.cells[tmpe], x.cells[tmpe2])
                    
                   

                }
                 
            //delej(idecko);
            }
            else 
            {
                //alert("ope2");

                headers[targetCellIndex].insertAdjacentElement('beforebegin', headers[cellIndex]);
                Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{

               //x.cells[tmpe2].insertAdjacentElement('beforebegin', x.cells[tmpe]);
                })
                //var w = (document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[cellIndex].colSpan)
                //alert("cellIndex: "+cellIndex+"act w: "+w);
                Array.from(document.getElementById(String(idecko)).querySelector("tbody").rows).forEach(x=>{
                for(var w = 0; w<(document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[parseInt(cellIndex)+1].colSpan);w++)
                {
                    //alert("prvni_arg: "+(celkem_spanu-w)+"druhej_arg:"+new_cell_index);
                    x.cells[targetCellIndex].insertAdjacentElement('beforebegin', x.cells[parseInt(cellIndex)+w]);
                    //x.cells[celkem_spanu-w].insertAdjacentElement('beforebegin', x.cells[new_cell_index]);
                } 
                //x.cells[targetCellIndex+1].insertAdjacentElement('beforebegin', x.cells[parseInt(cellIndex)]);
                // x.cells[targetCellIndex+1].insertAdjacentElement('beforebegin', x.cells[parseInt(cellIndex)]);
               // x.cells[celkem_spanu-1].insertAdjacentElement('beforebegin', x.cells[new_cell_index]);
                
                //alert("stop");
                //x.cells[targetCellIndex].insertAdjacentElement('beforebegin', x.cells[parseInt(cellIndex)+1]);
                
             });
            //delej(idecko);

            }
        }   
        
    premapuj(idecko);
    }


// KONEC POSUN SLOUPCU
//resizing(idecko);

});

});

// drag fce - end
//};

//_______________________________________

 

  var thElm1;
  var thElm2;
  var startOffsetx;
  var startOffsety;
  var lock;
  var str0 = "#";
  var str1 = String(idecko);
  var str2 =" td";

  var res = str0.concat(str1);
  var res2 = res.concat(str2);
//document.write(res2);
 // resiz(String(res2));
 Array.prototype.forEach.call(
    document.getElementById(String(idecko)).querySelectorAll(String(res2)),
    //document.getElementById(res2),
    function(td) {
      td.style.position = 'relative';

      var gripp = document.createElement('div');
      gripp.innerHTML = "&nbsp;";
      gripp.style.bottom = 0;
      gripp.style.right = "10px";
      gripp.style.left = 0;
      gripp.style.height = "3px";
      gripp.style.position = 'absolute';
      gripp.style.cursor = 'ns-resize';
    
      gripp.addEventListener('mousedown', function(fe) {

        thElm2 = td;
        startOffsety = td.offsetHeight - fe.pageY;
      
      });
      
      td.appendChild(gripp);
      
    }
    );



    Array.prototype.forEach.call(
    document.getElementById(String(idecko)).querySelectorAll(String(res2)),
    //document.getElementById(res2),
    function(td) {
      td.style.position = 'relative';
      var cellIndex = td.cellIndex;

      var grip = document.createElement('div');
      grip.innerHTML = "&nbsp;";
      grip.style.top = 0;
      grip.style.right = 0;
      grip.style.color = "red";
      grip.style.bottom = "5px";
      grip.style.position = 'absolute';
      grip.style.cursor = 'ew-resize';

      
      // TODO pro jeden colspan = "2" ... [cellIndex-1]....dodelat pro libovolny pocet
      grip.addEventListener('mousedown', function(e) {
        //alert("cellIndex: "+cellIndex);
        var sum = 0;
        for(var o = 0; o < document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount; o++)
        {
           // alert("iterace: "+o+"aktual"+document.querySelector("thead").rows[0].cells[o].colSpan);
            sum = sum + document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[o].colSpan;
        }
        var th_cnt = document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount;
        var rozdil = sum - th_cnt;
        //alert("Rozdil pro resizu: "+rozdil);
        thElm1 = document.getElementById(String(idecko)).querySelectorAll("td")[cellIndex];
        startOffsetx = td.offsetWidth - e.pageX;
        //alert(thElm1.cellIndex);
      });
      
      td.appendChild(grip);
    }
    );

   function premapuj(idecko)
  {
  Array.prototype.forEach.call(
    document.getElementById(String(idecko)).querySelectorAll(String(res2)),
    //document.getElementById(res2),
    function(td) {
      td.style.position = 'relative';

      var gripp = document.createElement('div');
      gripp.innerHTML = "&nbsp;";
      gripp.style.bottom = 0;
      gripp.style.right = "10px";
      gripp.style.left = 0;
      gripp.style.height = "3px";
      gripp.style.position = 'absolute';
      gripp.style.cursor = 'ns-resize';
    
      gripp.addEventListener('mousedown', function(fe) {

        thElm2 = td;
        startOffsety = td.offsetHeight - fe.pageY;
      
      });
      
      td.appendChild(gripp);
      
    }
    );



    Array.prototype.forEach.call(
    document.getElementById(String(idecko)).querySelectorAll(String(res2)),
    //document.getElementById(res2),
    function(td) {
      td.style.position = 'relative';
      var cellIndex = td.cellIndex;

      var grip = document.createElement('div');
      grip.innerHTML = "&nbsp;";
      grip.style.top = 0;
      grip.style.right = 0;
      grip.style.color = "red";
      grip.style.bottom = "5px";
      grip.style.position = 'absolute';
      grip.style.cursor = 'ew-resize';

      
      // TODO pro jeden colspan = "2" ... [cellIndex-1]....dodelat pro libovolny pocet
      grip.addEventListener('mousedown', function(e) {
        //alert("cellIndex: "+cellIndex);
        var sum = 0;
        for(var o = 0; o < document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount; o++)
        {
           // alert("iterace: "+o+"aktual"+document.querySelector("thead").rows[0].cells[o].colSpan);
            sum = sum + document.getElementById(String(idecko)).querySelector("thead").rows[0].cells[o].colSpan;
        }
        var th_cnt = document.getElementById(String(idecko)).querySelector("thead").querySelector("tr").childElementCount;
        var rozdil = sum - th_cnt;
        //alert("Rozdil pro resizu: "+rozdil);
        thElm1 = document.getElementById(String(idecko)).querySelectorAll("td")[cellIndex];
        startOffsetx = td.offsetWidth - e.pageX;
        //alert(thElm1.cellIndex);
      });
      
      td.appendChild(grip);
    }
    );
}

  Array.prototype.forEach.call(
    
    document.getElementById(String(idecko)).querySelectorAll(res),
    //document.getElementById(idecko),
    function(res) {
      res.style.resize = "both";
    }
    );
 

  document.getElementById(String(idecko)).addEventListener('mousemove', function (e) {
    if (thElm1) {
      //var x = this.cellIndex;
      
      thElm1.style.width = startOffsetx + e.pageX + 'px';
      //thElm1.style.resize = "horizontal";
      //thElm.style.height = startOffset + e.pageY + 'px';
    }
  } );


    document.getElementById(String(idecko)).addEventListener('mousemove', function (fe) {
    if (thElm2) {
      //thElm.style.width = startOffset + e.pageX + 'px';
      thElm2.parentNode.style.height = startOffsety + fe.pageY + 'px';
      //thElm2.style.resize = "horizontal";
    }
  });

    

  document.getElementById(String(idecko)).addEventListener('mouseup', function() {

    thElm1 = undefined;
    thElm2 = undefined;
    
  });


//resizing end

}

window.onload = function(){
            dyn("prvni");
            dyn("dalsi");
}
