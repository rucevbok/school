
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <netdb.h>
int main (int argc, char *argv[] )
{
    ////////////////////////////////////////// ARGS
    int login_flag = 0;
    int uid_flag = 0;
    int gid_flag = 0;
    int home_flag = 0;
    int shell_flag = 0;
    int gecos_flag = 0;
    char param[20];
    char *host_opt = NULL;
    char *port_opt = NULL;
    char *login_opt = NULL;
    char *uid_opt = NULL;
    char *login_uid_flag=NULL;
    int index;
    int c;
    
    opterr = 0;
    while ((c = getopt (argc, argv, "h:p:l:u:LUGNHS")) != -1)
        switch (c)
    {
        case 'h':
            host_opt = optarg;
     
            break;
        case 'p':
            port_opt = optarg;
         
            break;
        case 'l':
            login_opt = optarg;
      
            break;
        case 'u':
            uid_opt = optarg;
 
            break;
        case 'L':
            login_flag = 1;
            strcat(param,"l");
            break;
        case 'U':
            uid_flag = 1;
            strcat(param,"u");
            break;
        case 'G':
            gid_flag = 1;
            strcat(param,"g");
            break;
        case 'N':
            gecos_flag = 1;
            strcat(param,"n");
            break;
        case 'H':
            home_flag = 1;
            strcat(param,"h");
            break;
        case 'S':
            shell_flag = 1;
            strcat(param,"s");
            break;
        case '?':
            if (optopt == 'p')
                fprintf (stderr, "Option -%c requires an argument.\n", optopt);
            else if (isprint (optopt))
                fprintf (stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf (stderr,
                         "Unknown option character `\\x%x'.\n",
                         optopt);
            if (optopt == 'h')
                fprintf (stderr, "Option -%c requires an argument.\n", optopt);
            else if (isprint (optopt))
                fprintf (stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf (stderr,
                         "Unknown option character `\\x%x'.\n",
                         optopt);
            return 1;
        default:
            abort ();
    }
    if((login_opt==NULL) && (uid_opt==NULL) || (login_opt!=NULL) && (uid_opt!=NULL))
    {printf("error - bad argument's combination -u -l\n");
        return -1;}
    /////////////////////////////////////////// ARGS

    int s, n;
    struct sockaddr_in sin; struct hostent *hptr;
    char msg[80] = "";
    if ( argc < 3 ) {
        printf ("%s host port\n", argv[0] );   /* input error: need host & port */
        return -1;
    }
    if ( (s = socket(PF_INET, SOCK_STREAM, 0 ) ) < 0) { /* create socket*/
        perror("error on socket");  /* socket error */
        return -1;
    }
    sin.sin_family = PF_INET;              /*set protocol family to Internet */
    sin.sin_port = htons(atoi(port_opt));  /* set port no. */
    if ( (hptr =  gethostbyname(host_opt) ) == NULL){
        fprintf(stderr, "gethostname error: ");
        return -1;
    }
    memcpy( &sin.sin_addr, hptr->h_addr, hptr->h_length);
    if (connect (s, (struct sockaddr *)&sin, sizeof(sin) ) < 0 ){
        perror("error on connect"); return -1;   /* connect error */
    }
    //FLAG login-uid
    
    
    if (login_opt!= NULL)
    {login_uid_flag=1;}
    if(uid_opt != NULL)
    {login_uid_flag=0;}
    char flag[2];
    sprintf(flag, "%d", login_uid_flag);
    if ( write(s, flag, strlen(flag) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //_________________LOGIN
    if (login_opt!=NULL)
    {
        if ( write(s, login_opt, strlen(login_opt) +1) < 0 ) {  /* send message to server */
            perror("error on write");    return -1; /*  write error */
        }
        if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
            perror("error on read"); return -1; /*  read error */
        }
    }
    
    //_________________UID
    if(uid_opt!=NULL)
    {
        if ( write(s, uid_opt, strlen(uid_opt) +1) < 0 ) {  /* send message to server */
            perror("error on write");    return -1; /*  write error */
        }
        if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
            perror("error on read"); return -1; /*  read error */
        }
    }
    
    
    //___________________LOGIN_FLAG
    
    char str[2];
    sprintf(str, "%d", login_flag);
    if ( write(s, str, strlen(str) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //___________________UID_flag
    
    char str2[2];
    sprintf(str2, "%d", uid_flag);
    if ( write(s, str2, strlen(str2) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //___________________GID_flag
    
    char str3[2];
    sprintf(str3, "%d", gid_flag);
    if ( write(s, str3, strlen(str3) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //___________________GECOS_flag
    
    char str4[2];
    sprintf(str4, "%d", gecos_flag);
    if ( write(s, str4, strlen(str4) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //___________________HOME_FLAG
    
    char str5[2];
    sprintf(str5, "%d", home_flag);
    if ( write(s, str5, strlen(str5) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    
    //___________________SHELL_FLAG
    
    char str6[2];
    sprintf(str6, "%d", shell_flag);
    if ( write(s, str6, strlen(str6) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }

      //___________________param
    
    //printf("%s\n", param);
    if ( write(s, param, strlen(param) +1) < 0 ) {  /* send message to server */
        perror("error on write");    return -1; /*  write error */
    }
    
    if ( ( n = read(s, msg, sizeof(msg) ) ) <0) {  /* read message from server */
        perror("error on read"); return -1; /*  read error */
    }
    
    //printf ("received %d bytes: %s\n", n, msg);  /* print message to screen */
    /* close connection, clean up socket */
    bzero(msg,sizeof(msg));
    n = read(s, msg, sizeof(msg) );  
    n = read(s, msg, sizeof(msg) ); 
    printf ("%s\n", msg);
    if (close(s) < 0) { 
        perror("error on close");   /* close error */
        return -1;
    }
    
    return 0;
    
}
