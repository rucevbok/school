
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <netdb.h>
#include <pwd.h>
#include <errno.h>
#include <string.h>
int main (int argc, char *argv[])
{
    ////////////////////////////////////////// ARGS
    int login_flag = 0;
    int uid_flag = 0;
    int gid_flag = 0;
    int home_flag = 0;
    int shell_flag = 0;
    int gecos_flag = 0;
    char *host_opt = NULL;
    char *port_opt = NULL;
    char *login_opt = NULL;
    char *uid_opt = NULL;
    char param[90];
    char login_optimal[90];
    char vysledek[900];
    int index;
    int c,pid;
    int login_uid_flag=0;
    int uid;
    
    opterr = 0;
    while ((c = getopt (argc, argv, "h:p:l:u:LUGNHS")) != -1)
        switch (c)
    {
        case 'h':
            host_opt = optarg;
            break;
        case 'p':
            port_opt = optarg;
            break;
        case 'l':
            login_opt = optarg;
            break;
        case 'u':
            uid_opt = optarg;
            break;
        case 'L':
            login_flag = 1;
            break;
        case 'U':
            uid_flag = 1;
            break;
        case 'G':
            gid_flag = 1;
            break;
        case 'N':
            gecos_flag = 1;
            break;
        case 'H':
            home_flag = 1;
            break;
        case 'S':
            shell_flag = 1;
            break;
        case '?':
            if (optopt == 'c')
                fprintf (stderr, "Option -%c requires an argument.\n", optopt);
            else if (isprint (optopt))
                fprintf (stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf (stderr,
                         "Unknown option character `\\x%x'.\n",
                         optopt);
            return 1;
        default:
            abort ();
    }
    /////////////////////////////////////////// ARGS
    int s, t, sinlen;
    struct sockaddr_in sin;
    int i;
    char msg[80];
    struct hostent * hp;
    int j;
    int login_f,uid_f,gid_f,gecos_f,home_f,shell_f;
    
    if (argc < 2) {
        printf("%s port\n", argv[0] ); /* input error: need port no! */
        return -1;
    }
    if ( (s = socket(PF_INET, SOCK_STREAM, 0 ) ) < 0) { /* create socket*/
        printf("error on socket\n"); 
        perror("error on socket\n"); /* socket error */
        return -1;
    }
    sin.sin_family = PF_INET;              /*set protocol family to Internet */
    sin.sin_port = htons(atoi(port_opt));  /* set port no. */
    sin.sin_addr.s_addr  = INADDR_ANY;   /* set IP addr to any interface */
    if (bind(s, (struct sockaddr *)&sin, sizeof(sin) ) < 0 ) {
        printf("error on bind\n"); 
        perror("error on bind\n");
        return -1;  /* bind error */
    }
    if (listen(s, 5)) {
        printf ("error on listen\n");
        perror("error on listen\n"); /* listen error*/
        return -1;
    }
    sinlen = sizeof(sin);
    while (1) {
        
        /* accepting new connection request from client,
         socket id for the new connection is returned in t */
        if ( (t = accept(s, (struct sockaddr *) &sin, &sinlen) ) < 0 ) {
            printf("error on accept\n"); 
            perror("error on accept\n"); /* accept error */
            return -1;
        }
        if((pid = fork()) < 0)
        {return -1;}
        if (pid == 0)
        {
            hp=(struct hostent *)gethostbyaddr((char *)&sin.sin_addr,4,AF_INET);
            j=(int)(hp->h_length);
            printf( "From %s (%s) :%d.\n",inet_ntoa(sin.sin_addr), hp->h_name, ntohs(sin.sin_port) );
            bzero(msg,sizeof(msg));
            //Login-uid flag
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
            
            if((strcmp("1",msg))==0)
            {login_uid_flag=1;
               // printf("je to login\n");
            }
            else if((strcmp("0",msg))==0)
            {login_uid_flag=0;
                //printf("je to uid\n");
            }
            
            
            //login_optimal=msg;
            //strcpy(login_optimal, msg);
            
           // printf("length of message is %d\nmessage from client is: %s\n",strlen(msg),msg);
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");
                perror("error on write\n");
                return -1; /*  write error */
            }
            
            //_________________LOGIN
            if(login_uid_flag==1)
            {
                if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                    printf("error on read\n");
                    perror("error on read\n");         /*  read error */
                    return -1;
                }
                strcpy(login_optimal,msg);
                //login_optimal=msg;
                //strcpy(login_optimal, msg);
                
                //printf("length of message is %d\nmessage from client is: %s\n",strlen(msg),msg);
                if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                    printf("error on write\n");
                    perror("error on write\n");
                        return -1; /*  write error */
                }
            }
            //_________________UID
            if(login_uid_flag!=1)
            {
                if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                    printf("error on read\n");         /*  read error */
                    printf("error on read\n");
                    return -1;
                }
                uid=atoi(msg);
                
              //  printf("length of message is %d\nmessage from client is: %s\n",strlen(msg),msg);
                uid=atoi(msg);
              //  printf("UID: %d\n",uid );
                if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                    printf("error on write\n");
                    perror("error on write\n");
                    return -1; /*  write error */
                }
            }
            //___________________LOGIN_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n");
                perror("error on read\n");         /*  read error */
                return -1;
            }
            login_f= atoi (msg);
            //printf("login: %d\n",login_f );
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");    
                perror("error on write\n");
                return -1; /*  write error */
            }
            //___________________UID_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
            uid_f= atoi (msg);
          //  printf("UID: %d\n",uid_f );
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");
                perror("error on write\n");   
                 return -1; /*  write error */
            }
            //___________________GID_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
            gid_f= atoi (msg);
           // printf("GID: %d\n",gid_f );
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");
                perror("error on write\n");    
                return -1; /*  write error */
            }
            //___________________GECOS_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n");
                perror("error on read\n");         /*  read error */
                return -1;
            }
            gecos_f= atoi (msg);
           // printf("gecos: %d\n",gecos_f );
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");
                perror("error on write\n");    
                return -1; /*  write error */
            }
            //___________________HOME_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
            home_f= atoi (msg);
            //printf("home: %d\n",home_f );
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");
                perror("error on write\n");
                    return -1; /*  write error */
            }
            //___________________SHELL_FLAG
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
            shell_f= atoi (msg);
         //   printf("shell: %d\n",shell_f );
            
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n"); 
                perror("error on write\n");
                return -1; /*  write error */
            }
             //___________________param
            if ( read(t, msg, sizeof(msg) ) <0) {  /* read message from client */
                printf("error on read\n"); 
                perror("error on read\n");        /*  read error */
                return -1;
            }
           
           

            strcpy(param,msg);
           //  printf("parametry nove: %s\n",param);
            
            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n"); 
                perror("error on write\n");
                   return -1; /*  write error */
            }
            //__________________
            /* close connection, clean up sockets */
           // printf("home: %d %d %d %d %d %d \n",login_f,uid_f,gid_f,gecos_f,home_f,shell_f);
            
            //////////////////////////////////////////////////////////////////////////////////////////////////////
            
            
            struct passwd pwd;
            struct passwd *result;
            char *buf;
            size_t bufsize;
            int s;
            
            bufsize = sysconf(_SC_GETPW_R_SIZE_MAX);
            if (bufsize == -1)          /* Value was indeterminate */
                bufsize = 16384;        /* Should be more than enough */
            buf = malloc(bufsize);
            if (buf == NULL) {
                perror("malloc");
                exit(EXIT_FAILURE);
            }
         //   printf("uidecko %d\n",login_uid_flag );
            if(login_uid_flag==1)
            {
                //printf("lololol\n");
                s = getpwnam_r(login_optimal, &pwd, buf, bufsize, &result);
                if (result == NULL) {
                    if (s == 0)
                        printf("\n");
                    else {
                        errno = s;
                        perror("getpwnam_r");
                    }
                    strcpy(vysledek,"error: unknown login\n");
                    perror("error: unknown login");
                   
                    //exit(EXIT_FAILURE);
                }
            }
            
            if(login_uid_flag==0)
            {
                //printf("UID: %d\n",uid );
                s = getpwuid_r(uid, &pwd, buf, bufsize, &result);
                if (result == NULL) {
                    if (s == 0)
                        printf("\n");
                    else {
                        errno = s;
                        perror("getpwnam_r");
                    }
                    strcpy(vysledek,"error: unknown UID\n");
                    perror("error: unknown UID");
                    //exit(EXIT_FAILURE);
                }
            }
            
            int counter;
              char uid_integer[15];
              char gid_integer[15];   
            
             for(counter=0;counter<strlen(param);counter++)
             {

             switch(param[counter])
             {
             case 'l':  

                strcat (vysledek, pwd.pw_name);
                strcat (vysledek, " ");
                break;
            
             case 'u':
                sprintf(uid_integer, "%d", pwd.pw_uid);
                strcat(vysledek, uid_integer);
                strcat(vysledek, " ");
                break;
            
             case 'g':

                sprintf(gid_integer, "%d", pwd.pw_gid);
                strcat(vysledek, gid_integer);
                strcat(vysledek, " "); 
                break;
            
            case 'n':
                strcat (vysledek, pwd.pw_gecos);
                strcat (vysledek, " ");
                break;
            
            case 'h':
                strcat (vysledek, pwd.pw_dir);
                strcat (vysledek, " ");
                break;

            case 's':
                strcat (vysledek, pwd.pw_shell);
                strcat (vysledek, " ");
                break;
            }
            }

            if ( write(t, msg, strlen(msg) ) < 0 ) {  /* echo message back */
                printf("error on write\n");    return -1; /*  write error */
            }
            write(t, vysledek, strlen(vysledek));
            printf(vysledek);
            bzero(vysledek,sizeof(vysledek));
            //exit(EXIT_SUCCESS);
            
            
            
            
            
            
        }
        
    }
    if (close(t) < 0) { printf("error on close");perror("error on close\n"); return -1;} 
    
    // not reach below
    
    
    
    
    
    
    
    return 0;
}
