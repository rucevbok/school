#!/bin/bash
if [ "$1" == '-d' ];then

objdump -d  recfun | grep '>:' |  cut -c 18- | tr -d "<>:" | sed '/^_/d' | sed -e "s/@plt/_PLT/" | sed -e "4p"| uniq | grep $2
    mpole=$(objdump -d  recfun | sed -n '/[:alnum:]* <main>:/,/retq/p' | sed -n '/callq/p' | cut -c 47- | uniq | tr -d "<>" | sort | uniq | sed -e "s/@plt/_PLT/")
for x in `echo $mpole | tr " " "\n"`; do echo $2 '->' $x; done
    else
    echo ou
fi
