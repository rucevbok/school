<?php

#XQR:xvysta02



$shortopts  = "n";  // Required value


$longopts  = array(
    "input:",
    "query:",     
    "output:",
    "root:",   
    "qf:",
    
);

$options = getopt($shortopts, $longopts);
//var_dump($options);


//$string="SELECT price FROM";
$string=$options["query"];
$output_file=$options["output"];
$root=$options["root"];
$query_file=$options["qf"];
$input_file=$options["input"];
$helper=$options["help"];

if (isset($input_file)) {$xml = simplexml_load_file($input_file);}

if(isset($string) and (isset($query_file))) {exit(1);}
else if (isset($string)) {$string;}
else if (isset($query_file)) {$string=file_get_contents($query_file);}


if(isset($helper)) {echo $help;}

$prvni_vypis_rootu=1;
$zapisuju=0;
$posledni_vypis_rootu=1;
if (array_key_exists('n', $options)) {
    $vypis_hlavicky=1;
}
else {$vypis_hlavicky=0;}

echo $vypis_hlavicky."\n";
$nalezeno=0;



preg_match("/(?<=SELECT\s)[a-zA-Z0-9]*/", $string, $element);
preg_match("/(?<=LIMIT\s)[0-9]*/", $string, $limit);
preg_match("/(?<=FROM\s)(\w+)?(?:\.?(\w+)?)/", $string, $from);
preg_match("/(?<=WHERE\s).*(=|<|>|CONTAINS)\s*(\"\w*\"|\w*)/", $string, $hodnota); 

$pocet=$limit[0];

tvar_fromu();


function tvar_fromu(){
    global $zapisuju,$from,$atribut,$elem,$xml,$posledni_vypis_rootu,$root,$prvni_vypis_rootu,$output,$vypis_hlavicky,$output_file;
$mystring = $from[0];
$findme   = '.';
 echo "outtt_".$output."\n";
if (strcmp($mystring, "ROOT")==0) {

$output_file_var = fopen($output_file, "a");
                                                        
                                        if ($vypis_hlavicky==0)             //zjistuju jestli vypisuji na stdout nebo do souboru
                                            {$vypis_hlavicky=1;
                                            if(!isset($output_file)) {echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";}
                                            else if(isset($output_file))  
                                                fwrite($output_file_var, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");}

                                    if( (isset($root)) and ($prvni_vypis_rootu==1)) {
                                        $prvni_vypis_rootu=0; 
                                        if(!isset($output_file)) {echo "<".$root.">";}
                                        else if(isset($output_file))  {fwrite($output_file_var,"<".$root.">");}}
//volani funkce                                        
call_root($xml);

echo $zapisuju;
$output_file_var = fopen($output_file, "a");

if( (isset($root)) and ($posledni_vypis_rootu==1)) 
    {$posledni_vypis_rootu=0; 
    if(!isset($output_file)) {echo "</".$root.">";}
    else if(isset($output_file)) {fwrite($output_file_var,"</".$root.">");}}
return;


}

//je tam vubec tecka?
$pos = strpos($mystring, $findme);
if ($pos===false) {echo $mystring;
$output_file_var = fopen($output_file, "a");
echo "hlavicky".$vypis_hlavicky;
if ($vypis_hlavicky==0)             //zjistuju jestli vypisuji na stdout nebo do souboru
                                            {$vypis_hlavicky=1;
                                                echo "out_".$output_file."\n";
                                            if(!isset($output_file)) {echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";}
                                            else if(isset($output_file))  
                                                fwrite($output_file_var, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");}

                                    if( (isset($root)) and ($prvni_vypis_rootu==1)) {
                                        $prvni_vypis_rootu=0; 
                                        if(!isset($output_file)) {echo "<".$root.">";}
                                        else if(isset($output_file))  {fwrite($output_file_var,"<".$root.">");}}

    from_element($xml,$from);

$output_file_var = fopen($output_file, "a");

if( (isset($root)) and ($posledni_vypis_rootu==1)) 
    {$posledni_vypis_rootu=0; 
   
    if(!isset($output_file)) {echo "</".$root.">";}
    else if(isset($output_file_var)) {fwrite($output_file_var,"</".$root.">");}}
    return;
}   

else {

$mame_tecku=substr($mystring, 0, 1);

if(strcmp($mame_tecku, ".")==0) {$atribut = substr($mystring, 1);echo "JET TO TU\n";echo $atribut;



$output_file_var = fopen($output_file, "a");

if ($vypis_hlavicky==0)             //zjistuju jestli vypisuji na stdout nebo do souboru
                                            {$vypis_hlavicky=1;
                                                echo "out_".$output_file."\n";
                                            if(!isset($output_file)) {echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";}
                                            else if(isset($output_file))  
                                                fwrite($output_file_var, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");}

                                    if( (isset($root)) and ($prvni_vypis_rootu==1)) {
                                        $prvni_vypis_rootu=0; 
                                        if(!isset($output_file)) {echo "<".$root.">";}
                                        else if(isset($output_file))  {fwrite($output_file_var,"<".$root.">");}}



from_atribut($xml);
$output_file_var = fopen($output_file, "a");

if( (isset($root)) and ($posledni_vypis_rootu==1)) 
    {$posledni_vypis_rootu=0; 
        echo "konecek";
    if(!isset($output_file)) {echo "</".$root.">";}
    else if(isset($output_file_var)) {fwrite($output_file_var,"</".$root.">");}}
    return;







return;}

else{
$pos = strpos($mystring, $findme)."\n";


$atribut = substr($mystring, $pos+1); 
$elem = substr($mystring, 0,$pos);
echo $atribut."\n";
echo $elem."\n\n\n\n";



$output_file_var = fopen($output_file, "a");
echo "hlavicky".$vypis_hlavicky;
if ($vypis_hlavicky==0)             //zjistuju jestli vypisuji na stdout nebo do souboru
                                            {$vypis_hlavicky=1;
                                                echo "out_".$output_file."\n";
                                            if(!isset($output_file)) {echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";}
                                            else if(isset($output_file))  
                                                fwrite($output_file_var, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");}

                                    if( (isset($root)) and ($prvni_vypis_rootu==1)) {
                                        $prvni_vypis_rootu=0; 
                                        if(!isset($output_file)) {echo "<".$root.">";}
                                        else if(isset($output_file))  {fwrite($output_file_var,"<".$root.">");}}




from_element_atribut($xml,$elem,$atribut);
$output_file_var = fopen($output_file, "a");

if( (isset($root)) and ($posledni_vypis_rootu==1)) 
    {$posledni_vypis_rootu=0; 
        echo "konecek";
    if(!isset($output_file)) {echo "</".$root.">";}
    else if(isset($output_file_var)) {fwrite($output_file_var,"</".$root.">");}}
    return;
}
}
}
//___________________________________________________________________________________________________





function from_element($xml,$from)
{
	global $xml,$myxml;

 foreach ($xml->children() as $child)
{


    $new_xml=$child;
    $aktual=$child->getName();
    echo "jse ".$aktual . "\n";
    if (strcmp($aktual, $from[0])==0) {$myxml= $new_xml->asXML();element_zjisti($myxml);return;}
    else{ $xml= $new_xml;from_element($xml,$from);}


}
}

function from_element_atribut($xml, $elem,$atribut)
{
	global $xml,$atribut,$nalezeno,$myxml;

 foreach ($xml->children() as $child)
{


    $new_xml=$child;
    $aktual=$child->getName();

    if (strcmp($aktual, $elem)==0)
    {
        $xml= $new_xml; 
        foreach($xml->attributes() as $a => $b) 
        {
        if($a==$atribut){$myxml=$xml->asXML();element_zjisti($myxml);return;}
        }
    }
    else{$xml= $new_xml;from_element_atribut($xml,$elem,$atribut);}
}
}

function zjisti_atributy($xml){
global $xml,$atribut,$nalezeno;

foreach($xml->attributes() as $a => $b) {

    if($a==$atribut){$nalezeno=1;}
    else return;
}
}

function from_atribut($xml)
{

global $xml,$nalezeno,$atribut,$myxml;


 foreach ($xml->children() as $child)
{

   
    $new_xml=$child;
  
    $aktual=$child->getName();
    echo $aktual."\n";
     foreach($new_xml->attributes() as $a => $b) 
    {
    if($a==$atribut){$nalezeno=1;}
    else return;
    }
    if ($nalezeno==1) {$myxml=$new_xml->asXML();element_zjisti($myxml);return;}    
    if ($nalezeno==0) {$xml= $new_xml;from_atribut($xml);}


}


}


//___________________________________________________________________________________________________

function element_zjisti($myxml){
    global $element,$myxml;
   $xmlko = simplexml_load_string($myxml); 

   detect_elem($xmlko);
}



function detect_elem($xml){
    global $element,$myxml,$root_xml,$loaded,$output_file,$output_file_var,$hodnota;

   //$xmlko = simplexml_load_string($myxml);    
foreach ($xml->children() as $child)
{

    $new_xml=$child;
    $aktual=$child->getName();

    if (strcmp($aktual, $element[0])==0) {
                                            if($hodnota[0]!=""){tvar_where();}
                                            else{

                                                if (isset($output_file)) 
                                                    {
                                                        echo "tu";

                                                        $output_file_var = fopen($output_file, "a");
                                                        fwrite($output_file_var, $new_xml->asXML());
                                                  

                                                        
                                                    }


                                                else {
                                                     echo $new_xml->asXML();}
                                                ;}
                                        ;}
                                            
    else {detect_elem($new_xml);}


}


}




function call_root($xml){
    global $zapisuju,$hodnota,$element,$output_file,$vypis_hlavicky,$root,$prvni_vypis_rootu,$posledni_vypis_rootu,$pred_where,$pocet;


   //$xmlko = simplexml_load_string($myxml);    
foreach ($xml->children() as $child)
{

    $new_xml=$child;
    $aktual=$child->getName();

    if (strcmp($aktual, $element[0])==0) {
                                            if($hodnota[0]!=""){
                                                
                                                $pred_where=$new_xml->asXML();
                                                tvar_where();}
                                            else{
                                                if (isset($output_file)) 
                                                    {

                                                        if(isset($pocet))
                                                            {  if($zapisuju>=$pocet) {return;}}
                                                        //$puvodni=file_get_contents("vystupuj.txt");
                                                        //$text=$new_xml->asXML();
                                                        //file_put_contents("vystupuj.txt",$puvodni."\n".$text );
                                                        
                                                        $output_file_var = fopen($output_file, "a");
                                                        fwrite($output_file_var, $new_xml->asXML());
                                                        $zapisuju++;
                                                  
                 //   if ((isset($root)) && ($prvni_vypis_rootu==1)) ){$prvni_vypis_rootu=0;fwrite($output_file_var, ucfirst($root));}
                                                        
                                                    }


                                                else {

                                                     echo $new_xml->asXML();}
                                                ;}
                                        ;}
                                            
    else {call_root($new_xml);}


}


}

//___________________________________________________________________________________________________

function tvar_where(){
    global $hodnota,$operator,$pred_where,$leva_cast,$oper,$number,$literal,$vypis_hlavicky,$output_file,$atribut_where;
$mystring = $hodnota[0];

$findme   = '.';


//budeme hledat <,>,= a CONTAINS
$operator[0]= '<';
$operator[1]= '>';
$operator[2]= '=';
$operator[3]= 'CONTAINS';
$pos;
for($i=0;$i<4;$i++){

$pos = strpos($mystring, $operator[$i]);


if ($pos !== false) {$oper=$operator[$i];break;}

}

$pos_op=strpos($mystring,$oper);


$literate=substr($mystring, $pos_op+1,strlen($mystring));
preg_match("/[^\s]+/", $literate, $output);

$literal_pred_matchem=$output[0];

$prvni_znak_literalu=substr($literal_pred_matchem, 0,1);
if (strcmp($prvni_znak_literalu, "\"")==0) {
    $number!=true;
    preg_match("/\w+/", $literal_pred_matchem, $outout);
    $literal=$outout[0];
    echo  "LITERAL: ".$literal;

}
else if(strcmp($prvni_znak_literalu, "\"")!=0)
{
    $number=true;
    $literal=$literate;

}

//if($number!=true) {$literal=substr($literal, 1,strlen($literal)-2); }
//else if($number==true) {echo "je to cislo\n";}
echo "\n\n";
//echo $number;


$leva_cast=substr($mystring, 0 , $pos);
//od pocatku az do operatora je element-atribut, pote regexem odstranim whitespacy
preg_match("/[^\s]+/", $leva_cast, $vystup);
$leva_cast=$vystup[0];

//je tam vubec tecka?
$pos = strpos($leva_cast, $findme);
if ($pos!==false) 
{
    //tecka je na zacatku - takze vyraz ma tvar .atribut
    if($pos==0){
        $atribut_where= substr($leva_cast, 1,strlen($leva_cast));
        where_atribut($pred_where);
        }
    //tecka neni na zacatku - vyraz ma tvar element.atribut
    else {$atribut_where= substr($leva_cast, $pos+1,strlen($leva_cast)+5);$element_where= substr($leva_cast, 0,$pos);


        echo $element_where." ". $atribut_where;
        //echo "LITERAL: ".$literal;
        where_element_atribut($pred_where,$element_where,$atribut_where);
    };

}

else {
                $output_file_var = fopen($output_file, "a");
                
                if ($vypis_hlavicky==0)             //zjistuju jestli vypisuji na stdout nebo do souboru
                    {$vypis_hlavicky=1;
                                                
                    if(!isset($output_file)) {echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";}
                        else if(isset($output_file))  
                        fwrite($output_file_var, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");}

                if( (isset($root)) and ($prvni_vypis_rootu==1)) {
                    $prvni_vypis_rootu=0; 
                    if(!isset($output_file)) {echo "<".$root.">";}
                    else if(isset($output_file))  {fwrite($output_file_var,"<".$root.">");}}

where_element($pred_where,$leva_cast);}

                $output_file_var = fopen($output_file, "a");

                if( (isset($root)) and ($posledni_vypis_rootu==1)) 
                 {$posledni_vypis_rootu=0; 
                if(!isset($output_file)) {echo "</".$root.">";}
                else if(isset($output_file_var)) {fwrite($output_file_var,"</".$root.">");}}
                return;

}
//_____________________________________________________________________________________________________________________________________

function where_element($xml,$leva_cast)
{
    global $xml,$myxml,$leva_cast,$literal,$output_file,$oper,$number,$pocet,$zapisuju;
$cely_xml=$xml;


 foreach ($xml->children() as $child)
{


    $new_xml=$child;
    $aktual=$child->getName();


    if (strcmp($aktual, $leva_cast)==0) 
        {

            if ($number==true)
            {
     
              if ($oper=='<') {if($cely_xml->$aktual < $literal){

                
                  $output_file_var = fopen($output_file, "a");
                  fwrite($output_file_var, $cely_xml->asXML());
            return;}

                        }
              else if ($oper=='>') {if($cely_xml->$aktual > $literal){

            $output_file_var = fopen($output_file, "a");
            fwrite($output_file_var, $cely_xml->asXML());
            return;}

                        }
              else if ($oper=='=') {if($cely_xml->$aktual == $literal){

            $output_file_var = fopen($output_file, "a");
            fwrite($output_file_var, $cely_xml->asXML());
            return;}

                        }
            }

            else if($number!=true) //jedna se o string
            {
                    
            if ($oper=='<') {
                if(strcmp($cely_xml->$aktual, $literal)>0) {
                        if(isset($pocet))
                        { if($zapisuju>=$pocet) {return;}}
                    $zapisuju++;
            $output_file_var = fopen($output_file, "a");
            fwrite($output_file_var, $cely_xml->asXML());
            return;}
            }

            else if ($oper=='>') {
                if(strcmp($cely_xml->$aktual, $literal)>0) {
                        if(isset($pocet))
                        { if($zapisuju>=$pocet) {return;}}
                    $zapisuju++;
            $output_file_var = fopen($output_file, "a");
            fwrite($output_file_var, $cely_xml->asXML());
            return;}
            }

           else if ($oper=='=') {
            
            if(strcmp($cely_xml->$aktual, $literal)==0) {
            $output_file_var = fopen($output_file, "a");
            fwrite($output_file_var, $cely_xml->asXML());
            return;}
            }
            }





        }
    else{ $xml= $new_xml;where_element($xml,$leva_cast);}


}
}

function where_element_atribut($xml, $elem,$atribut)
{

    global $xml,$oper,$number,$nalezeno,$myxml,$literal,$output_file,$output_file_var;
    $cely_xml=$xml;

    //echo $literal."<-literal";
foreach ($xml->children() as $child)
{


    $new_xml=$child;
    $aktual=$child->getName();
    //echo $elem. " element a atribut" . $atribut."\n";
    //echo "aktual ".$aktual . $elem."\n";
    if (strcmp($aktual, $elem)==0)
    {
        $xml= $new_xml; 
        foreach($xml->attributes() as $a => $b) 
        {
        if($a==$atribut){
            echo "aktualni atribut: ".$b." - ".$literal."\n";

            if($number!=true)
            {

                if($oper=='=')
                {     if(strcmp($b, $literal)==0)
                      {
                    
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }

               if($oper=='>')
                {     if(strcmp($b, $literal)>0)
                      {
                    
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }
              
                 if($oper=='<')

                { 
                  if(strcmp($b, $literal)<0)
                      {
                     
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $new_xml->asXML());   
                      }
                 }
                 if($oper=='CONTAINS')

                {    
                  if(($cmp = strstr($b, $literal))==true)
                      {
                     
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }


           } 
           if($number==true)
           {
                echo "tady jsem\n";
            if($oper=='=')
                {     if($b==$literal)
                      {
                      echo "tadyasdbrwtsfijn";
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }
            if($oper=='>')
                {     if($b > $literal)
                      {
                      echo "tadyasdbrwtsfijn";
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }
            if($oper=='<')
                {     if($b<$literal)
                      {
                      echo "tadyasdbrwtsfijn";
                      $output_file_var = fopen($output_file, "a");
                      fwrite($output_file_var, $xml->asXML());   
                      }
                 }
            }
         }
        }
    }
    else{$xml=$new_xml;where_element_atribut($xml,$elem,$atribut);}
}
}


function where_atribut($xml)
{

global $xml,$atribut_where,$nalezeno,$atribut,$myxml,$output_file,$output_file_var,$literal;

 foreach ($xml->children() as $child)
{

    if($nalezeno==1) {return;}
    $new_xml=$child;
    
    $aktual=$child->getName();

     foreach($new_xml->attributes() as $a => $b) 
    {
      echo $a."\n";
    if($a==$atribut_where){
            if($b==$literal)
            {
                $output_file_var = fopen($output_file, "a");
                fwrite($output_file_var, $child->asXML()); 
                
                }
    }
   
    }
    
    if ($nalezeno==0) {$xml= $new_xml;where_atribut($xml);}


}


}




return 0;

?>