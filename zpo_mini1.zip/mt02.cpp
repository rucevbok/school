#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>



/*  Funkce pro �edot�nov� obraz (0-255) spo��t� konvoluci se zadan�m j�drem o velikost 3x3 typu float (CV_32FC1).
    Krajn� hodnoty v�sledn�ho obrazu ponechte 0.
	 Implementujte ru�n� pr�chodem obrazem, pro ka�d� pixel projd�te jeho okol� a prove�te konvoluci s j�drem.
    V�slednou hodnotu je nutno p�ed ulo�en�m do v�sledn�ho obrazu normalizovat.

	Povolen� metody a funkce OpenCV pro realizaci �kolu jsou:
		Mat:: rows, cols, step(), size(), at<>(), zeros(), ones(), eye()
    
*/
void convolution( cv::Mat& gray, const cv::Mat& kernel, cv::Mat& dst )
{	
	float x, inten, sumicka = 0;
	int o = -1;
	int p = -1;
	dst = cv::Mat::zeros( gray.size(), CV_32FC1 );

	if( kernel.rows != 3 || kernel.cols != 3 )
		return;

	/*  Working area - begin */
	
	// secteni hodnot v matici 
	for (o = 0; o <= 2; ++o)
	{
		for (p = 0; p <= 2; ++p)
		{
			sumicka = sumicka + std::abs(kernel.at<float>(o,p));
		}
	}
	if (sumicka < 1)
	{
		sumicka = 1;
	}
	
	// pruchod zdrojovym obrazkem
	for (int i = 1;i<gray.rows-1;i++){
	    for (int j = 1;j<gray.cols-1;j++){
	        float filtertotal = 0;
	        for(int k = 0; k<kernel.rows; k++)
	        {
	        	for(int l = 0; l<kernel.cols; l++)
	       		{
					
					inten = (float)gray.at<uchar>(i+k, j+l);
					x = inten*kernel.at<float>(k,l);
					filtertotal = filtertotal + x;
		       			
				}
	        }
	        // normalizace
	        dst.at<float>(i,j) = round(filtertotal/sumicka);
			}
	}
	
	/*  Working area - end */
	
}

/*  
		Funkce provede geometrickou transformaci obrazu s vyu�it�m interpolace nejbli���m sousedem.
		
		Vstupn� transformace popisuje transformaci pixel� ze vstupn�ho obrazu do v�stupn�ho.
		Vyu�ijeme inverzn�ho postupu (viz p�edn�ka), tedy vypo�teme inverzn� transformaci a
		pro ka�d� bod v�stupn� matice budeme hledat jeho pozici ve vstupn�m obrazu a pou�ijeme 
		interpolace nejbli���m sousedem k nalezen� hodnoty v�stupn�ho pixelu. 
		
*/
void geometricalTransform( const cv::Mat& src, cv::Mat& dst, const cv::Mat& transformation )
{
	// inverzn� transformace
	cv::Mat T = transformation.inv();
   
	// v�sledn� matice/obraz
	dst = cv::Mat::zeros(src.size(), CV_8UC1 );
	
	/*
		Pro ka�d� pixel v�stupn�ho obrazu
			1. najd�te jeho polohu ve zdrojov�m obrazu (pomoc� p�ipraven� inverzn� transformace v matici T)
				viz http://docs.opencv.org/modules/imgproc/doc/geometric_transformations.html?highlight=warpaffine#warpaffine
			2. zkontrolujte, nen�-li sou�adnice mimo zdrojov� obraz
			3. vyu�ijte interpolaci pomoc� nejbli���ho souseda k v�po�tu v�sledn�ho jasu c�lov�ho pixelu (vyu�ijte funkci cvRound())
			
	Povolen� metody a funkce OpenCV pro realizaci �kolu jsou:
		Mat:: rows, cols, step(), size(), at<>(), zeros(), ones(), eye(), cvRound()
			
	*/

	/*  Working area - begin */
	float x, y;
	int x_r, y_r;
	for (int i = 0; i < dst.rows; i++){
		for (int j = 0; j < dst.cols; j++){
			x = j*(T.at<float>(1,0)) + i*(T.at<float>(1,1)) + T.at<float>(1,2);
			y = j*(T.at<float>(0,0)) + i*(T.at<float>(0,1)) + T.at<float>(0,2);

			x_r = cvRound(x);
			y_r = cvRound(y);

			if (x_r < src.rows && x_r >= 0 && y_r < src.cols && y_r >= 0)
			{
				dst.at<uchar>(i, j) = src.at<uchar>(x_r, y_r);
			}

	}
	}

	/*  Working area - end */
	
	return;
}




//---------------------------------------------------------------------------
void checkDifferences( const cv::Mat test, const cv::Mat ref, std::string tag, bool save = false);
//---------------------------------------------------------------------------

//
// Examples of input parameters
//
// mt-02 image_path [rotation in degrees] [scale]


int main(int argc, char* argv[])
{
    std::string img_path = "";
    float s = 1.f;
    float r = 0.f;

	// check input parameters
	if( argc > 1 ) img_path = std::string( argv[1] );
	if( argc > 2 ) r = atof( argv[2] );
	if( argc > 3 ) s = atof( argv[3] );


	// load testing images
	cv::Mat src_rgb = cv::imread( img_path );

	// check testing images
	if( src_rgb.empty() ) {
		std::cout << "Failed to load image: " << img_path << std::endl;
		return -1;
	}

	// budeme pracovat s �edot�nov�m obrazem
	cv::Mat src_gray;
	cvtColor( src_rgb, src_gray, CV_BGR2GRAY );

	//---------------------------------------------------------------------------

	// konvoluce
	float ker[9] = { -1, -2, -1, 0, 0, 0, 1, 2, 1 };
	cv::Mat kernel( 3, 3, CV_32FC1, ker );
	cv::Mat conv_res, conv_ref;

	// naprogramovan� va�e �e�en�
	convolution( src_gray, kernel, conv_res );

	// referen�n� �e�en�
	cv::flip( kernel, kernel, -1 );
	cv::filter2D( src_gray, conv_ref, CV_32F, kernel );
	conv_ref *= 1.f/(cv::sum(abs(kernel)).val[0] + 0.000000001);
	// jeliko� filter2D funkce po��t� i hodnoty na okraj�ch v�stupn�ho obrazu (a my pro jednoduchost ne)
	// p�ed srovn�n�m vyma�eme krajn� hodnoty obrazu
	cv::rectangle( conv_ref, cv::Point(0,0), cv::Point(conv_ref.cols-1,conv_ref.rows-1), cv::Scalar::all(0), 1 );

	//---------------------------------------------------------------------------

	// geometrick� transformace
	
	// st�ed obrazu
	cv::Point2f c = cv::Point2f(0.5f*src_gray.cols,0.5f*src_gray.rows);
	
	// matice translace, rotace, zm�ny m���tka a v�sledn� transformace 
	cv::Mat T = cv::Mat::eye(3,3,CV_32FC1);
	cv::Mat R = cv::Mat::eye(3,3,CV_32FC1);
	cv::Mat S = cv::Mat::eye(3,3,CV_32FC1);
	cv::Mat M = cv::Mat::eye(3,3,CV_32FC1);	
	
	/* 
		Nastavte koeficienty matice translace, rotace a zm�ny m���tka 
		a transforma�n� matice vyn�sobte ve spr�vn�m po�ad� tak,
	 	aby v�sledn� obraz byl orotov�n a p�e�k�lov�n kolem sv�ho st�edu.
	 	Hodnoty jsou v prom�nn�ch 'c', 'r' a 's'.
	 	Pozor: 
	 		- �hel je ve stupn�ch (ne v radi�nech), 
	 		- chceme rotovat proti sm�ru hodinov�ch ru�i�ek (matice rotace je t�eba p�ed pou�it�m invertovat),
	 		- n�soben� matic A*B*C je v c++ zleva, nutno pou��t z�vorky (A*(B*C)), chceme-li n�sobit zprava   
	 	 
	Povolen� metody, makra a funkce OpenCV pro realizaci �kolu jsou:
		Mat:: rows, cols, at<>(), zeros(), ones(), eye(), inv(), cos, sin, CV_PI 	
	*/

	/*  Working area - begin */


	/*  Working area - end */

	//std::cout << M << std::endl;

	// v�sledn� obraz po transformaci
	cv::Mat tran_res, tran_ref;
	
	// va�e naprogramovan� va�e �e�en�
	geometricalTransform( src_gray, tran_res, M );
	cv::imwrite("tran_res.png", tran_res);

	// referen�n� �e�en�
	cv::Mat Mref = cv::getRotationMatrix2D( c, r, s );
	// warpAffine funkce intern� invertuje transforma�n� matici a interpoluje v�stupn� hodnoty pixel� ze vstupn�ho obrazu	
	cv::warpAffine( src_gray, tran_ref, Mref, src_gray.size(), cv::INTER_NEAREST, cv::BORDER_CONSTANT, cv::Scalar::all(0) );
	cv::imwrite("tran_ref.png", tran_ref);
	//std::cout << Mref << std::endl;

	//---------------------------------------------------------------------------


	// vyhodnocen�
	checkDifferences( conv_res, conv_ref, "convolution", true );
	checkDifferences( tran_res, tran_ref, "geometry", true );
	std::cout << std::endl;

    return 0;
}
//---------------------------------------------------------------------------




void checkDifferences( const cv::Mat test, const cv::Mat ref, std::string tag, bool save )
{
	double mav = 255., err = 255., nonzeros = 1000.;

	if( !test.empty() ) {
		cv::Mat diff;
		cv::absdiff( test, ref, diff );
		cv::minMaxLoc( diff, NULL, &mav );
		nonzeros = 1. * cv::countNonZero( diff ); // / (diff.rows*diff.cols);
		err = (nonzeros > 0 ? ( cv::sum(diff).val[0] / nonzeros ) : 0);

		if( save ) {
			diff *= 255;
			cv::imwrite( (tag+".png").c_str(), test );
			cv::imwrite( (tag+"_err.png").c_str(), diff );
		}
	}

	printf( "%s %.2f %.2f %.2f ", tag.c_str(), err, nonzeros, mav );

	return;
}
