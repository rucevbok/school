


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>

typedef struct parametry{
    int p,h,s,r;
} params;

params paramy;
int pom;

void param_load(const char * argv[])
{
    paramy.p=*argv[1];
    paramy.h=*argv[2];
    paramy.s=*argv[3];
    paramy.r=*argv[4];

}

sem_t *hackers, *serfers, *plavba, *nalodi, *molo, *kapitan;
int main(int argc, const char * argv[])
{
    void param_load(const char * argv[]);
    void hacks();
    void serfs();
    
    printf("%d\n",paramy.s);
    return 0;
}

void max_pocet_osob(){



}

void serfs()
{
    pom=paramy.p;
    while(pom!=0)
    {
    sem_wait(plavba);
    sem_wait(molo);
    sem_wait(nalodi);
    sem_post(plavba);
    sem_post(kapitan);
        printf("%d: serf:  started",pom);
        printf("%d: serf:  landing",pom);
    
    
    pom--;
    }


}

void hacks()
{
    pom=paramy.p;
    while(pom!=0)
    {
        sem_wait(plavba);
        sem_wait(molo);
        sem_wait(nalodi);
        printf("%d: hacker:  landing",pom);
        sem_post(plavba);
        sem_post(kapitan);
        if(sem_post(kapitan)==1){printf("%d: hacker:  %d: captain",pom,pom);}



printf("%d: hacker:  finished",pom);
        pom--;
    }
    
    
}