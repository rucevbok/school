#!/usr/bin/env python


import re
import urllib2
import urllib
import webbrowser
from BeautifulSoup import BeautifulSoup

def opens(find):
    find = find.replace(" ","+");
    URL = "http://www.opensubtitles.org/cs/search2/sublanguageid-cze,slo/moviename-"+find.lower();
    return URL

def links(url, lol):
    dict = {}
    link_list=[]
    
    splittext =  lol.split(" ")
    result = ' '.join(splittext[:1])
    #nalezeni odkazu a ulozeni do do slovniku
    for line in (urllib2.urlopen(url)).readlines():
		matchObj = re.match( r'.*style="width:80%".*>'+'.*', line, re.M|re.I)
		if matchObj:
			href = re.sub('.*href="(.*)">.*',r'\1',line)
			link_list.append((''.join(href.split())));
    i=1
    for link_list in link_list:
        dict[i] = link_list
        #print link_list
        i=i+1
    
    names(url, lol)
    #print dict
    vstup=raw_input("Vlozte cislo filmu: ")
    vstup=int(vstup)
    #print dict[vstup]
    url_vybrany_film="http://www.opensubtitles.org"+dict[vstup]
    #hledani odkazu na titulkovy soubor na strance filmu
    
    print url_vybrany_film
    down(url_vybrany_film,dict)
    return link_list


def down(url_vybrany_film,dict):
    slovnik = {}
    vysl=""
    link_list=[]
    print url_vybrany_film
    for line in (urllib2.urlopen(url_vybrany_film)).readlines():
        matchObj = re.match( r'.*<span class="p">[0-9]|[.]<.*>'+'.*', line, re.M|re.I)
        if matchObj:
            vysl = re.sub('.*href="(.*)" .*',r'\1',line)
            link_list.append((''.join(vysl.split())));
    i=1
    for link_list in link_list:
        slovnik[i] = link_list
        link_list
        i=i+1
    print slovnik
    releasy(url_vybrany_film)
    rel=raw_input("Zvolte release: ")
    rel=int(rel)
    down_link="http://www.opensubtitles.org"+slovnik[rel]

    urllib.urlretrieve (down_link, "lol.zip")

    return down_link


def releasy(url_vybrany_film):
    rellist=[]
    for line in (urllib2.urlopen(url_vybrany_film)).readlines():
        matchObj = re.match( r'.*<br />[A-Z].*', line, re.M|re.I)
        if matchObj:
            href = re.sub('.*<br />(.*)<br />.*',r'\1',line);
            rellist.append((''.join(href.split())));
        i=1
    for rellist in rellist:
        print i,rellist
        i=i+1
    
    
    return rellist


def names(url,  lol):
    print url
    #nalezeni nazvu odpovidajicich filmu
    nameslist=[]
    for line in (urllib2.urlopen(url)).readlines():
        matchObj = re.match( r'.*<td style="width:80%".*', line, re.M|re.I)
        if matchObj:
            href = re.sub('.*title="(.*)" .*',r'\1',line);
            href2 = re.sub('titulky(.*)',r'\1',href);
            nameslist.append((''.join(href2.split())));
        i=1
    for nameslist in nameslist:
        print i,nameslist
        i=i+1
            
        
    return nameslist

print " "
print "*---------------------------------------*"
print "* Automaticke stahovani titulku         *"
print "* Jaroslav Vystavel, xvysta02           *"
print "* FIT VUT v Brne                        *"
print "*---------------------------------------*"
print " "
lol = raw_input("Vlozte nazev filmu: ");
print "-----------------------------------------"

url = opens(lol);

link_list = links(url, lol);
#name = names(url, lol);
