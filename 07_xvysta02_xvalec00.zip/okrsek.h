#include <simlib.h>

#define PLENTY 2 // Pocet plent ve volebni mistnosti
#define KOMISE 5 // Pocet lidi k komisi

/**
 * Volebni okrsek
 */
class Okrsek : public Process {
public:
	static unsigned okrsekCnt;
	unsigned okrsek;

	double PlatneHlasy = 0;
	double NeplatneHlasy = 0;
	double PocVolicu = 0;
	double PocLidi = 0;
	double zacZpracHl, konZpracHl = 0;

	Facility Urna; // Volebni urna
	Facility Plenty[PLENTY]; // Volba za plentou
	Queue PlentyQueue;
	Facility Komise[KOMISE]; // Komise
	Queue KomiseQueue;
	Queue HlasyQueue;

 	Okrsek() : Process(), okrsek(okrsekCnt++) {}

 	void Behavior();
};