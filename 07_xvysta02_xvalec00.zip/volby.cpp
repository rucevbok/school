/**
 * @TODO 1) generovani volicu podle casu - v Generator upravit podle Time prichody (casteji/mene casteji)
 * @TODO 2) hlasy v urne zpracovat komisi
 * @TODO 3) sepsani zapisu, odvoz...
 * @TODO 4) spustit vic (cca tech 100) okrsku najednou - Event?
 */

#include "okrsek.h"
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

#define HODINA 60.0
#define POCETOKRSKU 10

const double T_REGISTRACE = 25.0/60.0; // Doba registrace u komise - Exp(25s)
const double T_ZAPLENTOU = 20.0/60.0; // Doba stravena za plentou - Exp(20s)
const double T_URNA = 3.0/60.0; // Doba stravena u urny pri vhozeni hlasu - Exp(3s)
const double T_VOLIC = 2.5;//50.0/60.0; // Generovani volicu
const double T_ZPRACHLASU = 20.0/60.0; // Doba zpracovani jednoho hlasu
const double T_ZAPIS = 5; // Sepsani zapisu
const double T_ODVZAPIS = 45; // Odvoz zapisu
const double T_CENTRALA = 3; // Odevzdani hlasu centrale

const double T_KONEC1 = HODINA * 8;  // konec simulace prvni den
const double T_ZACATEK2 = T_KONEC1; // zacatek simulace druhy den
const double T_KONEC2 = T_ZACATEK2 + HODINA * 6;  // konec simulace druhy den
const double T_KONEC = T_KONEC2 + HODINA * 4;

const double VolebniUcast = 0.33;

Facility Centrala; // Centrala - zpracovava zapisy o volbach
Queue CentralaQueue("Volebni urna");

Histogram TabulkaCentrala("Cekaci doby na centrale", 0, 1, 20);

class Hlas;
class Volic;
class Generator;

/**
 * Volebni hlas ve volebni urne
 */
class Hlas : public Process {

public:
	Okrsek *Okr;
	Hlas(Okrsek *okr) : Process(), Okr(okr) {}

	void Behavior() {
		Into(Okr->HlasyQueue); // odevzdany hlas v urne dokud neskonci volby
		Passivate();

		int cislo = -1;
		komise:
		// - - - KOMISE - - - 
		// kontrola, zda je clen komise volny, aby mohl zpracovat hlas
		for (int numb = 0; numb < KOMISE; numb++) 
			if (!Okr->Komise[numb].Busy()) {
				cislo = numb; // nezaneprazdneny clen komise
				break; 
			}

		// pokud jsou clenove komise zaneprazdneni, hlas ceka na zpracovani (fronta KomiseQueue)
		// az je hlas aktivovan, zkusi znovu zabrat clena komise
		if (cislo == -1) {
			Into(Okr->KomiseQueue);
			Passivate();
			goto komise;
		}

		// volebnimu hlasu se venuje vyse vybrany clen komise
		Seize(Okr->Komise[cislo]);
		Wait(Exponential(T_ZPRACHLASU));
		//Release(Okr->Komise[cislo]);
		// prvni, kdo cekal na komisi se aktivuje
		if (Okr->KomiseQueue.Length() > 0) {
			(Okr->KomiseQueue.GetFirst())->Activate();
		}

	}

};

/**
 * Volic ve volebni mistnosti
 */
class Volic : public Process { // trida volicu
	double Prichod; // cas prichodu kazdeho volice

public:
	Okrsek *Okr;
	Volic(Okrsek *okr) : Process(), Okr(okr) {}

	void Behavior() { 
		// VOLEBNI UCAST - 
		
		Prichod = Time;

		int cislo = -1;
		komise:
		// - - - KOMISE - - - 
		// volic u komise kvuli registraci
		for (int numb = 0; numb < KOMISE; numb++) 
			if (!Okr->Komise[numb].Busy()) { // kontrola zaneprazdnenosti komise
				cislo = numb; // nezaneprazdneny clen komise
				break; 
			}

		// pokud jsou clenove komise zaneprazdneni, volic ceka (fronta KomiseQueue)
		// az je volic aktivovan, znovu se snazi zaregistrovat
		if (cislo == -1) {
			Into(Okr->KomiseQueue);
			Passivate();
			goto komise;
		}

		//volic zabere urciteho clena komise a registruje se (Exp(25s)), pak komisi opousti
		Seize(Okr->Komise[cislo]);
		Wait(Exponential(T_REGISTRACE));
		Release(Okr->Komise[cislo]);
		// prvni, kdo cekal na komisi se aktivuje
		if (Okr->KomiseQueue.Length() > 0) {
			(Okr->KomiseQueue.GetFirst())->Activate();
		}

		// - - - PLENTY - - -
		// volic za plentou
		int num = -1;

		plenta:
		// volic u plenty
		for (int numb = 0; numb < PLENTY; numb++) 
			if (!Okr->Plenty[numb].Busy()) { // kontrola nepouzivane plenty
				num = numb; // volna plenta
				break; 
			}

		// pokud neni plenta volna, volic ceka (fronta PlentyQueue)
		// az je volic aktivovan, znovu se snazi jit za plentu
		if (num == -1) {
			Into(Okr->PlentyQueue);
			Passivate();
			goto plenta;
		}

		//volic zabere plentu (Exp(20s)), pak plentu opousti
		Seize(Okr->Plenty[num]);
		Wait(Exponential(T_ZAPLENTOU));
		Release(Okr->Plenty[num]);
		// prvni, kdo cekal na plentu se aktivuje
		if (Okr->PlentyQueue.Length() > 0) {
			(Okr->PlentyQueue.GetFirst())->Activate();
		}

		// - - - URNA - - -
		// volic vhodi hlas do urny
		Seize(Okr->Urna);
		Wait(T_URNA);
		Release(Okr->Urna);

		(new Hlas(Okr))->Activate();
		// Activate(Time);

	
	} // Behavior
};

/**
 * Prevede double na 2 desetinna mista a string 
 * @param  d Double cislo
 * @return   String daneho cisla
 */
string doubStr(double d, unsigned prec) {
	ostringstream oss; // output to string
	
	oss << setprecision(prec) << fixed << d;
	string str = oss.str(); // retrieve output string
	

	return str;
}

/**
 * Definice metody Behavior
 */
void Okrsek::Behavior() {
	const double T_ZACATEK1 = Time; // zacatek simulace prvni den
	unsigned den = 1;
	double prvniDenLidi, druhyDenLidi = 0;
	double prvniDenVolici, druhyDenVolici = 0;
	double volebniUcast = 0;
	string statistika;

	string urnaName, plentaName, komiseName, komiseQueName, plentaQueName;
	stringstream toString;
	stringstream num;
	toString << okrsek + 1;
	urnaName = "Urna Okr ";
	urnaName += toString.str();
	plentaName = "Plenta Okr ";
	plentaName += toString.str(); 
	komiseName = "Komise Okr ";
	komiseName += toString.str();
	komiseQueName = "Fronta ke komisi Okr ";
	komiseQueName += toString.str();
	plentaQueName = "Fronta k plente Okr ";
	plentaQueName += toString.str();

	Urna.SetName(urnaName.c_str());
	//KomiseQueue.SetName(komiseQueName.c_str());
	//PlentyQueue.SetName(plentaQueName.c_str());
	for (int i = 0; i < PLENTY; ++i)
	{
		Plenty[i].SetName(plentaName.c_str());
	}
	for (int i = 0; i < KOMISE; ++i)
	{
		Komise[i].SetName(komiseName.c_str());
	}

	statistika = "- - OKRSEK c." + toString.str() + " - -\n";

	while(1) {
		if(Random() > VolebniUcast) // obcan, co nejde volit
			PocLidi++;
		else { // obcan, ktery jde volit
			PocLidi++;
			PocVolicu++;
			(new Volic(this))->Activate(); // generovani volice
			Wait(Exponential(T_VOLIC));

			if (den == 1 && Time >= T_KONEC1) // konec prvniho dne voleb
			{
				prvniDenLidi = PocLidi;
				prvniDenVolici = PocVolicu;
				volebniUcast = PocVolicu * 100 / PocLidi;
				// Print("PRVNI DEN VOLEB\nPocet lidi: %.0f, pocet volicu: %.0f, ucast v procentech: %.2f\n\n", 
				// PocLidi, PocVolicu, volebniUcast);
				statistika += "Prvni den voleb: " + doubStr(prvniDenVolici, 0) + " volicu\n";

				den = 2;
			}

			if (den == 2 && Time >= T_KONEC2) // konec druheho dne voleb
			{
				druhyDenLidi = PocLidi - prvniDenLidi;
				druhyDenVolici = PocVolicu - prvniDenVolici;
				volebniUcast = druhyDenVolici * 100 / druhyDenLidi;
				// Print("DRUHY DEN VOLEB\nPocet lidi: %.0f, pocet volicu: %.0f, ucast v procentech: %.2f\n\n", 
				// druhyDenLidi, druhyDenVolici, volebniUcast);

				statistika += "Druhy den voleb: " + doubStr(druhyDenVolici, 0) + " volicu\n";
				break;
			}
		}
	}

	// zacZpracHl = Time;
	// Print("Zacatek pocitani hlasu: %f\n", zacZpracHl);
	while(! HlasyQueue.Empty()) {
		// platne a neplatne hlasy
		if(Random() > 0.99) 
			NeplatneHlasy++;
		else 
			PlatneHlasy++;

		(HlasyQueue.GetFirst())->Activate();
	}

	volebniUcast = PocVolicu * 100 / PocLidi;
	// Print("CELKOVE VOLBY\nPocet lidi: %.0f, pocet volicu: %.0f, ucast v procentech: %.2f\n\n", 
	// 	PocLidi, PocVolicu, volebniUcast);
	// Print("Pocet platnych hlasu: %.0f, pocet neplatnych: %.0f, procento platnych: %.2f\n\n",
	// 	PlatneHlasy, NeplatneHlasy, PlatneHlasy * 100 / PocVolicu);
	// Print("Pocet hlasu ve volebni urne: %.0f\n\n\n", NeplatneHlasy + PlatneHlasy);

	statistika += "Celkovy pocet moznych volicu: " + doubStr(PocLidi, 0) + "\n";
	statistika += "Z toho k volbam prislo: " + doubStr(PocVolicu, 0) + "\n";
	statistika += "Volebni ucast v tomto okrsku: " + doubStr(volebniUcast, 2) + "\n";
	statistika += "Pocet hlasu v urne: " + doubStr(NeplatneHlasy + PlatneHlasy, 0) + "\n\n";

	Print(statistika.c_str());

	// - - SEPSANI ZAPISU - -
	int cislo = -1;
	zapis:
	// az komise dokonci zpracovani hlasu, sepise zapis
	// cekani 
	for (int numb = 0; numb < KOMISE; numb++) 
		if (!Komise[numb].Busy()) { // kontrola zaneprazdnenosti komise
			cislo = numb; // nezaneprazdneny clen komise
			break; 
		}

	// pokud jsou clenove komise zaneprazdneni, ceka se
	if (cislo == -1) {
		Into(KomiseQueue);
		Passivate();
		goto zapis;
	}

	// vybere se clen komise, ktery sepise zapis
	Seize(Komise[cislo]);
	Wait(Exponential(T_ZAPIS));
	Release(Komise[cislo]);
	// prvni, kdo cekal na komisi se aktivuje
	if (KomiseQueue.Length() > 0) {
		(KomiseQueue.GetFirst())->Activate();
	}

	// - - ODVOZ ZAPISU - -
	Seize(Komise[cislo]);
	Wait(Exponential(T_ODVZAPIS));

	double zac = Time;
	Seize(Centrala);
	Wait(Exponential(T_CENTRALA));
	Release(Centrala);
	TabulkaCentrala(Time - zac);

	Release(Komise[cislo]);

	

	// - - VYPISY SPOJENE S VOLEBNIM OKRSKEM
	// for (int i = 0; i < PLENTY; ++i) {
	// 	Plenty[i].Output();
	// }
	// for (int i = 0; i < KOMISE; ++i) {
	// 	Komise[i].Output();
	// }
	// Urna.Output();
	// KomiseQueue.Output();
	// PlentyQueue.Output();
	// HlasyQueue.Output();
}

/**
 * Generovani voleb v kazdem okrsku
 */
class Generator : public Event {
	void Behavior() {
		for (int i = 0; i < POCETOKRSKU; ++i)
		{
			(new Okrsek)->Activate();
		}
	}
};

unsigned Okrsek::okrsekCnt = 0;

int main(int argc, char *argv[])
{
	// INICIALIZACE MODELU
	SetOutput("volby.out");
	
	//
	//  - - PRVNI DEN VOLEB - -
	//  
	Init(0, T_KONEC);
	RandomSeed(time(NULL));

	// INICIALIZACE OBJEKTŮ
	
	(new Generator)->Activate();

	Print(" VOLBY --- Simulace voleb\n\n");

	// SIMULACNI BEH
	Run();
	

	TabulkaCentrala.Output();

	return 0;
}
