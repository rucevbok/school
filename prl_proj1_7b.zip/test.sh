#!/bin/bash


if [ $# -eq 2 ];then
numbers=$1;
procesors=$2
else
numbers=$1;
fi;

#preklad cpp zdrojaku
mpic++ --prefix /usr/local/share/OpenMPI -o mss mss.cpp


#vyrobeni souboru s random cisly
#dd if=/dev/urandom bs=1 count=$numbers of=numbers
dd if=/dev/urandom bs=1 count=$numbers of=numbers >/dev/null 2>&1
#spusteni
mpirun --prefix /usr/local/share/OpenMPI -np $procesors mss $numbers $procesors

#uklid
rm -f mss numbers

