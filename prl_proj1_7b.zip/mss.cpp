#include <mpi.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

 #define TAG 0
 
 int main(int argc, char *argv[])
 {
    int numprocs=4;               //pocet procesoru
    int myid;                   //muj rank
    int neighnumber;            //hodnota souseda
    int mynumber;               //moje hodnota
    MPI_Status stat;            //struct- obsahuje kod- source, tag, error
    vector<int> items;
    int leng;
    //MPI INIT
    vector<int> mynumbers;
    vector<int> neighnumbers;
    vector<int> tempnumbers;
    vector<int> zaloha;
    vector<int> finalni;
    finalni.clear();
    std::chrono::steady_clock::time_point end;
    std::chrono::steady_clock::time_point start;
    MPI_Init(&argc,&argv);                          // inicializace MPI 
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);       // zjistĂ­me, kolik procesĹŻ bÄ›ĹľĂ­ 
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);           // zjistĂ­me id svĂ©ho procesu 
    
    //NACTENI SOUBORU
    /* -proc s rankem 0 nacita vsechny hodnoty
     * -postupne rozesle jednotlive hodnoty vsem i sobe
    */
    
    if(myid == 0){
        char input[]= "numbers";                          //jmeno souboru    
        int number;                                     //hodnota pri nacitani souboru
        int invar= 0;                                   //invariant- urcuje cislo proc, kteremu se bude posilat
        fstream fin;                                    //cteni ze souboru
        fin.open(input, ios::in);                   

        while(fin.good()){
            number = fin.get();
            if(!fin.good()) break;                      //nacte i eof, takze vyskocim
            std::cout<<number<<" ";
            items.push_back(static_cast<unsigned char>(number));
        }//while
        fin.close();       
        int items_per_proc = items.size()/numprocs;
        int rest_of_items = items.size()%numprocs;
        //printf("num %d\n",numprocs );
        int index = 0;
        for (int i = 0; i<numprocs; i++)
        {
            if(i<rest_of_items)
            {
                items_per_proc++;
            }
           // printf("items_per_proc: %d\n",items_per_proc );
            MPI_Send(&items_per_proc, 1, MPI_INT, i, TAG, MPI_COMM_WORLD);
            
            MPI_Send(&items[index], items_per_proc, MPI_INT, i, TAG, MPI_COMM_WORLD);
            index=index + items_per_proc;
            int cnt = items_per_proc;
            while(cnt>0)
            {
              //  items.pop_back();
                cnt--;
            }
            
            //items.pop_back();
            //printf("proc: %d item count: %d\n",i,items_per_proc );
            if(i<rest_of_items)
            {
                items_per_proc--;
            }
        }
    

    }

    MPI_Recv(&leng, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
    //printf("%d\n",leng );
    mynumbers.resize(leng);
    MPI_Recv(&mynumbers[0], leng, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
   // printf("ahoj myID: %d a leng: %d a cislo: %d\n", myid,leng,mynumbers[0]);
    for (int i = 0; i < leng; i++)
    {
       // printf("ahoj myID: %d a leng: %d a cislo: %d\n", myid,leng,mynumbers[i]);
    }

   // start = std::chrono::steady_clock::now();
    sort(mynumbers.begin(), mynumbers.end());
    
    //cout << "\nArray after sorting using "
    //     "default sort is : \n";
    //for (int i = 0; i < leng; ++i)
        //cout << mynumbers[i] << " ";
   // printf("\n");
   // printf("_______________________________");
   // printf("\n");
    int oddlimit= 2*(numprocs/2)-1;                 
    int evenlimit= 2*((numprocs-1)/2);              
    int halfcycles= numprocs/2;
    int cycles=0;      
    int leng_souseda;
    for(int j=1; j<=halfcycles; j++){
        cycles++;           //pocitame cykly, abysme mohli udelat krasnej graf:)
        //printf("LOOOOL\n");
        //sude proc 
        if((!(myid%2) || myid==0) && (myid<oddlimit))
        {
            // 0 a 2
            //printf("MUJID %d\n",myid );
            //mynumbers.resize(leng);
            MPI_Send(&leng, 1, MPI_INT, myid+1, TAG, MPI_COMM_WORLD);          
            MPI_Send(&mynumbers[0], leng, MPI_INT, myid+1, TAG, MPI_COMM_WORLD);          

            MPI_Recv(&leng_souseda, 1, MPI_INT, myid+1, TAG, MPI_COMM_WORLD, &stat);   
            mynumbers.clear();
            mynumbers.resize(leng_souseda);
            MPI_Recv(&mynumbers[0], leng_souseda, MPI_INT, myid+1, TAG, MPI_COMM_WORLD, &stat);   

        }

        else if(myid<=oddlimit)
        {
            // 1 a 3
            //printf("MUJID %d\n",myid );

            
            MPI_Recv(&leng_souseda, 1, MPI_INT, myid-1, TAG, MPI_COMM_WORLD, &stat); 
            neighnumbers.clear();
            neighnumbers.resize(leng_souseda);
            MPI_Recv(&neighnumbers[0], leng_souseda, MPI_INT, myid-1, TAG, MPI_COMM_WORLD, &stat); 
    

            mynumbers.insert(mynumbers.end(),neighnumbers.begin(),neighnumbers.end());
            sort(mynumbers.begin(),mynumbers.end());
            for (int x=0; x<mynumbers.size(); x++)
            {
               // printf("mynums: %d\n",mynumbers[x] );
            }
            //printf("_\n");
            MPI_Send(&leng_souseda, 1, MPI_INT, myid-1, TAG, MPI_COMM_WORLD);
            MPI_Send(&mynumbers[0], leng_souseda, MPI_INT, myid-1, TAG, MPI_COMM_WORLD);   
            zaloha = mynumbers;
            mynumbers.clear();
            for (int x=(leng_souseda); x <=(zaloha.size()-1); x++)
            {
                mynumbers.push_back(zaloha[x]);
            }
           // mynumbers.resize(leng);
           // mynumbers = zaloha;
        }
        else{
        }

        if((myid%2) && (myid<evenlimit)){
            // 1
            //printf("MUJID %d\n",myid );

            
            MPI_Send(&leng, 1, MPI_INT, myid+1, TAG, MPI_COMM_WORLD); 
            //mynumbers.resize(leng);
            MPI_Send(&mynumbers[0], leng, MPI_INT, myid+1, TAG, MPI_COMM_WORLD);          
            //printf("leng: %d \n",leng);
            MPI_Recv(&leng, 1, MPI_INT, myid+1, TAG, MPI_COMM_WORLD, &stat);  
            mynumbers.clear();
            mynumbers.resize(leng);
            MPI_Recv(&mynumbers[0], leng, MPI_INT, myid+1, TAG, MPI_COMM_WORLD, &stat);   

        }//if liche
         else if(myid<=evenlimit && myid!=0){
            // 2
            //printf("MUJID %d\n",myid );
            neighnumbers.clear();
            MPI_Recv(&leng_souseda, 1, MPI_INT, myid-1, TAG, MPI_COMM_WORLD, &stat); 
            neighnumbers.resize(leng_souseda);
            //printf("%d - leng_souseda: %d\n",myid,leng_souseda);
            MPI_Recv(&neighnumbers[0], leng_souseda, MPI_INT, myid-1, TAG, MPI_COMM_WORLD, &stat); 
            
            mynumbers.insert(mynumbers.end(),neighnumbers.begin(),neighnumbers.end());

            sort(mynumbers.begin(),mynumbers.end());
            for (int x=0; x<mynumbers.size(); x++)
            {
                //printf("mynums: %d\n",mynumbers[x] );
            }
            //printf("_\n");
            zaloha = mynumbers;
            MPI_Send(&leng_souseda, 1, MPI_INT, myid-1, TAG, MPI_COMM_WORLD);
            MPI_Send(&mynumbers[0], leng_souseda, MPI_INT, myid-1, TAG, MPI_COMM_WORLD);   
            mynumbers.clear();
            for (int x=(leng_souseda); x<=(zaloha.size()-1); x++)
            {
                mynumbers.push_back(zaloha[x]);
            }

           // mynumbers.resize(leng);
           // mynumbers = zaloha;
            //cout<<"sl: "<<myid<<endl;
        }//else if (liche)
        else{//sem muze vlezt jen proc, co je na konci
        }//else
        
    }


    if(myid==0)
    {
 //       end = std::chrono::steady_clock::now();
 
        cout << endl;
    }
    
    for(int i=0; i<numprocs; i++){
       if(myid == i) 
        {
            //leng = mynumbers.size();
           // printf("%d sends to \n",myid, );
            MPI_Send(&leng, 1, MPI_INT, 0, TAG,  MPI_COMM_WORLD);
            MPI_Send(&mynumbers[0], leng, MPI_INT, 0, TAG,  MPI_COMM_WORLD);
        }
       if(myid == 0){

           neighnumbers.clear();
           MPI_Recv(&leng_souseda, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &stat); 
           neighnumbers.resize(leng_souseda);
           MPI_Recv(&neighnumbers[0], leng_souseda, MPI_INT, i, TAG, MPI_COMM_WORLD, &stat);
           for(int a=0; a<leng_souseda; a++)
            {

                cout << neighnumbers[a] << endl;
            
            }
            

       }
    }


    MPI_Finalize(); 
    return 0;

 }//main

