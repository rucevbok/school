--{-# OPTIONS -Wall #-} 
module Main (main) where

import System.IO
import System.Environment
import Data.Char
import System.Exit
import Data.List
import Data.String
import Data.Array
import Control.Monad
import Data.Maybe
import Data.List.Split
import Text.Printf
import Data.Ord
import Data.Function

import qualified Data.Set as Set


type KState = String
type KSymbol = Char

type SofSes = Set.Set (Set.Set String)

data KAutomat = KA
    { states :: Set.Set String
    , start :: KState
    , final :: Set.Set String
    , trans :: [Transition]
    , setW :: Set.Set (Set.Set String)
    , setP :: Set.Set (Set.Set String)
    } deriving (Eq,Show,Read,Ord)

data SetOfStates = SetOfSt
    { initP :: Set.Set String   
    } deriving (Eq,Ord,Show)

data Transition = Trans
    { fromState :: String
    , fromSym :: Char
    , toState :: String
    } deriving (Eq,Ord,Show,Read)

data Transik = Transs
    { fromStatee :: String
    , fromSyme :: Char
    } deriving (Eq)



getTuringMachine :: FilePath -> IO KAutomat

getTuringMachine path = do
    content <- readFile path
    return (createFA (lines content))

isItStdin :: [Char] -> Bool
isItStdin "stdin" = True
isItStdin _ = False

replace' :: Eq b => b -> b -> [b] -> [b]
replace' a b = map (\x -> if (a == x) then b else x)

replace :: Eq a => [a] -> [a] -> [a] -> [a]
replace [] _ _ = []
replace s find repl =
    if take (length find) s == find
        then repl ++ (replace (drop (length find) s) find repl)
        else [head s] ++ (replace (tail s) find repl)



show' :: Show a => [a] -> String
show' = intercalate "" . map show

charToString :: Char -> String
charToString c = [c]

showDetails :: (String, Char, String) -> String
showDetails (name, uid, sh) = name ++ "," ++ charToString uid ++ "," ++ sh

poDvou ::[a] -> [a] -> [a]
poDvou [] [] = []
poDvou (l:ls) (a:as) = (l : a :[]) ++ poDvou ls as 


main :: IO ()
main = do
    args <- getArgs
    let (simulate, inFile) = procArgs args-- ('a', "test.in")
    if (simulate == 't') 
        then do     
            ts <- isItWellDefined $ getTuringMachine inFile
            if ( null(a2 ts \\ a1 ts) == True )
                then 
                    --putStrLn $ show $ zip [1..] . sort . map sort $ map Set.toList $ Set.toList $ reduce (Set.fromList[final ts, (states ts)Set.\\(final ts)]) (Set.fromList[(final ts)])  ts
                    printKA $ createDFA  (reduce (Set.fromList[final ts, (states ts)Set.\\(final ts)]) (Set.fromList[(final ts)]) ts) ts

                else 
                   -- print $ show $ createDFA ((reduce (Set.fromList[final ts, (states ts)Set.\\(final ts)]) (Set.fromList[(final ts)]) ts) $ (dodelejStavy ts)) 
                   --putStrLn $ reduce (Set.fromList[final ts, (states ts)Set.\\(final ts)]) (Set.fromList[(final ts)]) (dodelejStavy ts)
                   printKA $ createDFA (reduce (Set.fromList[final (dodelejStavy ts), (states (dodelejStavy ts))Set.\\(final (dodelejStavy ts))]) (Set.fromList[(final (dodelejStavy ts))]) (dodelejStavy ts)) ( dodelejStavy ts)
                    
        else do 
            ts <- isItWellDefined $ getTuringMachine inFile
            printKA ts
            --print "stdin"

      
a2 ts =  [states ++ "," ++ letter| states <- (Set.toList $ states ts), letter <- map (:[]) (getAlphabet ts)]


a1 ts =  zrusSeznam $ chunksOf 2 (poDvou (map fromState $ (trans ts)) (map (:[]) (map fromSym $ (trans ts))))

--deletuj [[a]] -> [[a]]
deletuj (as,ls) = [as, (delete "qqq" ls)]
--zrusSeznam :: [[a]] -> [a]
zrusSeznam [] = []
zrusSeznam (x:xs) = intercalate "," x : zrusSeznam xs


--udelejSeznamSeznamu ([ls],[ys]) = "["++[ls]++[ys]++"]"

getRule = getRule' . splitOn ","
getRule' :: [String] -> Transition
getRule' [q1,[sym],q2] = Trans q1 sym q2
getRule' _ = error "bad transition syntax"


--minimal :: KAutomat -> KAutomat 
minimal ts = reduce ts
    
getPs :: KAutomat -> SofSes
getPs ts = Set.fromList [(final ts),((states ts)Set.\\(final ts))]


--createDFA :: Set.Set (Set.Set String) -> KAutomat -> KAutomat
createDFA setPe ts@(KA states start final trans setW setP) =
    (KA statese starte finale transe setWw setPp) where
                statese = Set.fromList $ map show $ [1..length(map Set.toList $ (Set.toList setPe))]
                starte = createNewInit setPe start ts
                finale = Set.fromList $ map show $ (findEkvClassforFinal (Set.toList final) (zip [1..] . sort . map sort $ (map Set.toList $ (Set.toList setPe))) setPe) --findCorespondentFromZip final (zip [1..] . sort . map sort $ (map Set.toList $ (Set.toList setPe))) 
                --transe = reverse (priradEkvTridy (updateTransitions setPe trans [] ts) setPe ts)--sort $ union (trans)(map getRule (map (++ ",SINK") (a2 ts \\ a1 ts)))
                --transe = reverse (updateTransitions setPe trans [] ts)
                --transe = reverse (priradEkvTridy (updateTransitions setPe trans [] ts) (zip [1..] . sort . map sort $ (map Set.toList $ (Set.toList setPe))) ts)
                transe = nub $ (priradEkvTridy (trans) (zip [1..] . sort . map sort $ (map Set.toList $ (Set.toList setPe))) ts)
                setWw = setW
                setPp = setP

--ekvClass state classes = second (head (filter (\x -> (first x) == state) classes))
--(zip [1..] . sort . map sort $ s).


priradEkvTridy ls zip_setP ts = map (\x -> Trans {fromState = (findCorespondentFromZip (fromState x) zip_setP), fromSym = (fromSym x), toState = (findCorespondentFromZip (toState x) zip_setP)}) (ls)

findEkvClassforFinal [] zip_setP setP = []
findEkvClassforFinal x [] setP = []
findEkvClassforFinal x zip_setP setPe = 
    if (elem (head x) (snd $ head $ zip_setP))
        then
            [ fst $ head $ zip_setP] ++ findEkvClassforFinal (tail x) (zip [1..] . sort . map sort $ (map Set.toList $ (Set.toList setPe))) setPe
        else
            findEkvClassforFinal x (tail zip_setP) setPe


findCorespondentFromZip x [] = ""
findCorespondentFromZip x zip_setP =
    if(elem x (snd $ head $ zip_setP))
        then
            show $ fst $ head $ zip_setP
        else
            findCorespondentFromZip x (tail zip_setP)


findCorespondent state [] cnt = (show cnt)
--findCorespondent [] _ cnt = (show cnt)
findCorespondent state setP cnt 
    | null(state) = (show cnt)
    
    | otherwise = do
        let setoP = setP
        let act_ls = (head setP)
        let cntnew = cnt + 1
        let statek = do
            if (elem state act_ls) 
                then 
                    ""
                else 
                    "not_empty_list"            
        findCorespondent statek (tail setoP) cntnew

createNewInit setP start ts = searchInLoLists (map Set.toList $ Set.toList $ setP) start [] 0



searchInLoLists listOfLists start ls cnt
    | (null(ls)==False) = show cnt
    | otherwise = do
        let actual = do
            if (elem start (head listOfLists))
                then
                    ["no"]
                else
                    []
        let cnto = cnt + 1
        searchInLoLists (tail listOfLists) start actual cnto


--updateTransitions :: Set.Set (Set.Set String) -> [Transition] -> [Transition]
updateTransitions setP trans newTrans ts
    | (Set.size (setP))==0  = newTrans
    | otherwise = do
        let fromSt = map show $ sort $ vynasobFrom (Set.size setP) (length (getAlphabet ts))  -- [1, 1, 2, 2, 3, 3]
        let sym =  vynasobAbc (getAlphabet ts) (Set.size setP)                                 -- [a, b, a, b, a, b]
        --let toSt = map pairToList (zip fromSt sym)                                          -- [[1,a],[1,b],[2,a],[2,b],[3,a],[3,b]]
        -- TODO: let neco = fceNvoa fromSt sym ...fce ktera na vstup dostane seznam fromSt a seznam sym, dycky si vezme heady obou seznamu,
        -- udela dvojnasobnej filtr stejne jak na radku 187, dostanu seznam prechodu, vezmu prvni prechod, vezmu z nej toState a podivam se ve ktere 
        -- ekvivalencni tride se nachazi. Vysledkem funkce bude seznam hodnot toState ve vyslednym MKA
       --- let seznamPuvodnichFromstavu = novaFce fromSt sym [] ts
        let realToSt = vratTridu fromSt sym setP [] ts
        let setikP = Set.empty
        updateTransitions setikP trans realToSt ts

vynasobFrom set 0 = []
vynasobFrom set num = [x |x <- [1..set]] ++ vynasobFrom set (num-1)

vynasobAbc alpha 0 = []
vynasobAbc alpha num = alpha ++ vynasobAbc alpha (num-1)


        --[1, 1, 2, 2, 3, 3] [a, b, a, b, a, b]
-- novaFce fromSt sym ts
--     | null(fromSt) = vysledek 
--     | otherwise = do
--         let actual_fromState = head fromSt
--         let puvodni_stav = (fromState (vratStavZEkvTridy (map Set.toList $ (Set.toList setP)) (read (actual_fromState) :: Int)))
--         let actual_fromSym = head sym
--         let puvodni_fromSt = (fromState (filter (\x->(fromSym x == actual_fromSym)) (filter (\x->(fromState x == puvodni_stav ))(trans ts))))
--         let vysledekNew = vysledek ++ puvodni_fromSt
--         novaFce (tail fromSt) (tail sym) vysledekNew ts

vratTridu seznam_puv_fromst seznam setP prechody ts
    | null(seznam) = prechody
    | otherwise = do
        let fromek = head seznam_puv_fromst
        let symbek = head seznam
        let puvodni_fromstav =  (vratStavZEkvTridy (map Set.toList $ (Set.toList setP)) (read (fromek) :: Int)) 
        let toSt =  filter (\x->(fromSym x == symbek)) (filter (\x->(fromState x == puvodni_fromstav ))(trans ts)) 
        
        let prechodyN = toSt ++ prechody
        vratTridu (tail seznam_puv_fromst)(tail seznam) setP prechodyN ts


vratStavZEkvTridy setoP 1 = head  (head setoP)
vratStavZEkvTridy setoP num = vratStavZEkvTridy (tail setoP) (num-1)

pairToList :: (a, a) -> [a]
pairToList (x,y) = [x,y]

reduce :: Set.Set (Set.Set String) -> Set.Set (Set.Set String) -> KAutomat -> Set.Set (Set.Set String) 
reduce setP setW ts   
    | (Set.size (setW))==0  = setP               
    | otherwise = do
        let (setA, newW) = Set.deleteFindMin setW
        let (newsetP, newsetW) = firstFor setP newW setA (getAlphabet ts) ts
        reduce newsetP newsetW ts     


firstFor :: Set.Set (Set.Set String) -> Set.Set (Set.Set String) -> Set.Set String -> [Char] ->  KAutomat -> (Set.Set (Set.Set String), Set.Set (Set.Set String)) 
firstFor setP setW _ [] ts = (setP,setW)
firstFor setP setW setA (c:cs) ts 
    | null((c:cs)) = (setP, setW)
    | otherwise = do
        let setX = Set.fromList (map fromState $ (fromCtoA (Set.toList $ setA) (filter (\x->(fromSym x == c))(trans ts)) ts))
        let setY = getSetY setP setX Set.empty
        let (newsetP, newsetW) = modifyP setP setW setX setY
        firstFor newsetP newsetW setA cs ts

--getSetY :: Set.Set (Set.Set String) -> Set.Set String -> 
getSetY setP setX setY 
    | (Set.size(setP))==0 = setY
    | otherwise = do
        let (actual, restofP) = Set.deleteFindMin setP
        let newY = Set.union setY (intersectAndDiff actual setX)
        getSetY restofP setX newY

intersectAndDiff setY setX = 
    if ((Set.size(Set.intersection setY setX)/=0) && (Set.size(Set.difference setY setX)/=0))
        then
            setY
        else
            Set.empty


modifyP setP setW setX setY 
    | (Set.size setY)==0 = (setP,setW)

    | otherwise = do
        let newsetP = replaceNth (fromJust $ (elemIndex (Set.toList $ setY) (map Set.toList $  Set.toList $ setP ))) (deletuj $ span (/="qqq") $ ((intersect ( Set.toList $ setY) (Set.toList setX)) ++ ["qqq"] ++ (( Set.toList $ setY) \\ (Set.toList setX))))  (map Set.toList $ (Set.toList $ setP ))
        let setNewSetP = Set.fromList (map Set.fromList $ newsetP)
        let newsetW = do
            if (Set.member setY setW)
                then
                    setW
                else
                    if (Set.size(Set.intersection setX setY) <= Set.size(setY Set.\\ setX))
                        then
                            Set.insert (Set.intersection setX setY) setW 
                        else
                            Set.insert (setY Set.\\ setX) setW
        let setY = Set.empty
        modifyP setNewSetP newsetW setX setY

 
fromCtoA [] set_x_sym ts = []
fromCtoA (a:as) set_x_sym ts = (filter (\x->(toState x == a))(set_x_sym)) ++ fromCtoA as set_x_sym ts



replaceNth 0 newVal (x:xs) = newVal ++ xs 
replaceNth n newVal (x:xs) = x : replaceNth (n-1) newVal xs


getRuled' :: [String] -> Transition
getRuled' [q1,[sym],q2] = Trans q1 sym q2
getRuled' _ = error "bad transition syntax"

getRuledd :: [String] -> Transik
getRuledd [q1,[sym],q2] = Transs q1 sym
getRuledd _ = error "bad transition syntaxx"
--compareTrans :: [Transition] -> Bool
--compareTrans ls = True

createFA :: [String] -> KAutomat
createFA (statese : starte : finale : transitionse ) = 
    if null transitionse
        then error "zadne stavy"
        else KA
            (Set.fromList $ (splitOn "," statese))
            starte
            (Set.fromList $ (splitOn "," finale))
            (map getRule transitionse)
            (Set.fromList[(Set.fromList $ (splitOn "," finale))])
            (Set.fromList [(Set.fromList $ (splitOn "," finale)),((Set.fromList $ (splitOn "," statese))Set.\\(Set.fromList $ (splitOn "," finale)))])
createFA _ = error "neco spatne"


isItWellDefined :: IO KAutomat -> IO KAutomat
isItWellDefined ts = ts
 

dodelejStavy :: KAutomat -> KAutomat
dodelejStavy ts@(KA states start final trans setW setP) =
    (KA statese starte finale transe setWw setPp) where
                statese = Set.union (states)(Set.fromList $ (splitOn "," "SINK"))
                starte = start
                finale = final
                transe = sort $ union (trans)(map getRule (map (++ ",SINK") (a2 ts \\ a1 ts)))
                setWw = Set.fromList[final]
                setPp = getPs ts

getAlphabet :: KAutomat -> [Char]
getAlphabet ts =  nub $ (map fromSym (trans ts))
    

prictiJedna :: Int -> Int
prictiJedna i = i + 1

printKA :: KAutomat -> IO ()
printKA ts = do
            putStrLn $ intercalate "," $ Set.toList $ (states ts)
            putStrLn $ id $  (start ts)
            putStrLn $ intercalate "," $ Set.toList $ (final ts) 
            putStrLn . unlines . map showDetails $ sort $ (zip3 (map fromState $ (trans ts)) (map fromSym $ (trans ts)) (map toState $ (trans ts)) )
            -- print $ (\x -> x+1) $ digitToInt $ head $ last $ Set.toList $ (states ts) WTF?
            --putStrLn $ show $ map Set.toList $ Set.toList $ (setP ts)
            --putStrLn $ show $ map Set.toList $ Set.toList $ (setW ts)


procArgs :: [String] -> (Char, String)

procArgs [x] 
    | x=="-i" = ('i', "stdin")
    | x=="-t" = ('t', "stdin")
    | otherwise = error "unknown option"
-- 
procArgs [x,y]
    | (x=="-t") = ('t',y)
    | (x=="-i") = ('i',y)
    | otherwise = error "unknown option"
--
procArgs [x,y,z]
    | ((x=="-i" && y=="-t") || (y=="-i" && x=="-t")) = ('b', z)
    | otherwise = error "unknown option"
procArgs _ = error "too many arguments"
 
