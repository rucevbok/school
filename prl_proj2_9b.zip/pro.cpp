// Autor: Jaroslav Vystavěl
// Login: xvysta02
// Tento zdrojový kód vznikl jako součást školního projektu do předmětu PRL na FIT VUT v Brně.
// Implementace Přiřazení pořadí preorder vrcholům

#include <mpi.h>
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <bits/stdc++.h>
#include <math.h>
#include <numeric>
#include <chrono>

using namespace std;
#define TAG 0

typedef pair<char, char> vertex;
typedef vector<vector <vertex> > AdjList;
vector<vertex> vector_vertexu;
vector<vertex> e_tour;
vector<vertex> e_tour_final;
AdjList globalAdjList;
int v;
int counter = 0;
vertex my_edge;
std::chrono::steady_clock::time_point ende;
std::chrono::steady_clock::time_point start;

void createEdge(char source, char dest, int i, AdjList &adjList, AdjList &adjCopy)
{
            vertex vet1(source, dest);      // dopredna hrana
            adjList[i].push_back(vet1);

            vertex vet1rev(dest, source);   // zpetna hrana 
            adjList[i].push_back(vet1rev);

            vertex vet_zal1(source, dest);  // hrana do unikatniho seznamu
            adjCopy[i].push_back(vet_zal1);  
}

void createAdjLst(std::string input, AdjList &adjList, int const& edges, AdjList &adjCopy){

    char source, dest, weight;
    if( input.length() == 2)
    {
        source = input[0];
        dest = input[1];
        createEdge(source, dest, 0, adjList, adjCopy);

        source = input[1];
        dest = input[0];
        createEdge(source, dest, 1, adjList, adjCopy);
        return;
    }
    for(int i = 0; i < input.length(); ++i){
        //printf("abo: %c\n", input[i] );
        source = input[i];

        if(i == 0)
        {
            dest = input[1];
            createEdge(source, dest, i, adjList, adjCopy); 

            dest = input[2];
            createEdge(source, dest, i, adjList, adjCopy);  

        }
        
        else if ((2*i+2) >= input.length() || (2*i+1) >= input.length())      // uzel nema leveho, praveho nebo oba potomky
        {

            if ((2*i+1) < input.length())                                   // uzel ma praveho potomka
            {
                dest = input[2*i+1];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
            if ((2*i+2) < input.length())                                  // uzel ma leveho potomka
            {
                
                dest = input[2*i+2];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
            if (i%2==1)
            {
                 
                dest = input[(i-1)/2];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
            else
            {
                 
                dest = input[i/2-1];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
        }
        else
        {

            dest = input[2*i+1];
            createEdge(source, dest, i, adjList, adjCopy); 

            dest = input[2*i+2];
            createEdge(source, dest, i, adjList, adjCopy);  
            if (i%2==1)
            {
                 
                dest = input[(i-1)/2];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
            else
            {
                 
                dest = input[i/2-1];
                createEdge(source, dest, i, adjList, adjCopy); 
            }
        }
        
          
    }
}
void printCompleteAdjacencyList(string input, AdjList const& adjList, int &v ){

    for(int i = 0; i < v; ++i){

        int adjNodes = adjList[i].size();
        printf("Adjacent of: %c ma %d", input[i], adjNodes);

        if(adjNodes > 0){
            for(int j = 0; j < adjNodes; ++j){
                printf(" ->[(%c, %c)]", adjList[i][j].first, adjList[i][j].second);
                counter++;
            }
        }else{
            printf(" -> NONE");
        }

        printf("\n");
    }
 
}

 int main(int argc, char *argv[])
 {
    int numprocs;               //pocet procesoru
    int myid;                   //muj rank
    int neighnumber;            //hodnota souseda
    int mynumber;               //moje hodnota
    MPI_Status stat;            //struct- obsahuje kod- source, tag, error

    //MPI INIT
    MPI_Init(&argc,&argv);                          // inicializace MPI 
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);       // zjistĂ­me, kolik procesĹŻ bÄ›ĹľĂ­ 
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);           // zjistĂ­me id svĂ©ho procesu 
 


        //printf("%d\n", numprocs);
        //printf("%s\n",argv[1] );
        int v = strlen(argv[1]);
        //printf("pocet v %d\n",v );
        
        std::string input = argv[1];
        e_tour.reserve(numprocs);
        AdjList adjList(input.length());
        AdjList adjCopy(input.length());
        AdjList e_tour_table(3*input.length());
        int edges = numprocs;
        createAdjLst(input, adjList, edges, adjCopy);
 

        size_t total_size{ 0 };
        for (auto const& items: adjCopy){
            total_size += items.size();
        }
        vector_vertexu.reserve(total_size);
        for (auto const& items: adjCopy){
            vector_vertexu.insert(end(vector_vertexu), begin(items), end(items));
        }

    if(myid == 0)
    {
        
        for (int i = 0; i < vector_vertexu.size(); ++i)
        {
            
            MPI_Send(&vector_vertexu[i], 1, MPI_INT, i, TAG, MPI_COMM_WORLD);

        }

        //MPI_Send(&vector_vertexu[0], 1, MPI_INT, numprocs-1, TAG, MPI_COMM_WORLD);
    }
    
    MPI_Recv(&my_edge, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
    //printf("Jsem %d a moje hrana je %c %c\n",myid, my_edge.first,my_edge.second );
    vertex my_next;
    for(int y = 0; y < v; y++)
    {
        for (int x = 0; x < adjList[y].size(); x++)
        {
            //printf("%c %c\n",adjList[y][x].first, adjList[y][x].second );
            if(my_edge == adjList[y][x] && my_edge.first == adjList[y][x+1].second && my_edge.second == adjList[y][x+1].first)
            {
                    
                if ((x+2) >= adjList[y].size())
                {
                    //printf("%d >= %d\n",(x+2),adjList[y].size() );
                    my_next = adjList[y][0];
                    //printf("1) JA, %d, jsem nasel %c %c a my_next je: %c %c\n",myid, my_edge.first, my_edge.second, my_next.first,my_next.second );
                
                }
                else
                {
                    my_next = adjList[y][x+2];
                    //printf("%d < %d\n",(x+2),adjList[y].size() );
                    //printf("2) JA, %d, jsem nasel %c %c a my_next je: %c %c\n",myid, my_edge.first, my_edge.second, my_next.first,my_next.second );

                }
            }
        }   
    }
    MPI_Send(&my_next, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD);

    //printf("[ETOUR] JA, %d, jsem nasel %c %c a my_next je: %c %c\n",myid, my_edge.first, my_edge.second, my_next.first,my_next.second );
    


    if(myid == 0)
    {

        for (int i = 0; i < numprocs; ++i)
        {
            vertex iok;
            MPI_Recv(&iok, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &stat);
            e_tour.push_back(iok);
            //printf("DOSTAL JSEM (%d): %c %c\n",myid, iok.first, iok.second );
        }
        for (int i = 0; i < numprocs; ++i)
        {
            vertex opacne;
            opacne.first = vector_vertexu[i].second;
            opacne.second = vector_vertexu[i].first;
            e_tour_table[i].push_back(opacne);
            e_tour_table[i].push_back(vector_vertexu[i]);
            e_tour_table[i].push_back(e_tour[i]);

        }
        vertex opacnej;
        opacnej.first = e_tour_table[0][0].second;
        opacnej.second = e_tour_table[0][0].first;



        vertex k_o;
        k_o.first = '_';
        k_o.second = '_';
        vertex actual;
        actual.first = input[0];
        actual.second = input[1];
        for (int i = 0; i < numprocs; ++i)
        {
            if (actual == e_tour_table[i][0])
            {
                e_tour_final.push_back(e_tour_table[i][0]);
                actual = e_tour_table[i][2];
                //printf("po zmene: %c %c \n", actual.first, actual.second);
                e_tour_final.push_back(actual);
                e_tour_table[i][0] = k_o;   
                break;             
            }
        }

        for (int i = 0; i < numprocs; ++i)
        {
            for (int a = 0; a < numprocs; ++a)
            {
                if (actual == e_tour_table[a][0])
                {
                   
                    e_tour_final.push_back(e_tour_table[a][2]);
                    e_tour_table[a][0] = k_o;
                    actual = e_tour_table[a][2];
                }
            }

        }

        for (int i = 0; i < numprocs; ++i)
        {
            MPI_Send(&e_tour_final[i], 1, MPI_INT, i, TAG, MPI_COMM_WORLD);
            //printf("vysl: %c %c\n",e_tour_final[i].first, e_tour_final[i].second );
        }

    }

    int weight;
    int my_val;
    MPI_Recv(&my_edge, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD, &stat);
    //printf("[ET_final] JA, %d, mam hranu: %c %c",myid, my_edge.first, my_edge.second);
    
    size_t found_first, found_second;
    found_first = input.find(my_edge.first);
    found_second = input.find(my_edge.second);
    int succ_id;
    if (found_first < found_second)
    {
        
        weight = 1;
    }
    else
    {
        
        weight = 0;
    }
    //printf(" [%d] w: %d\n",myid,weight);
    if (myid ==(numprocs-1))
    {
        my_val = 0;
    }
    else
    {
        my_val = weight;
    }
    
        //succ_id = myid + ;
        vector<int> all_weights;
        all_weights.reserve(numprocs);
        MPI_Allgather(&weight, 1, MPI_FLOAT, &all_weights[0], 1, MPI_FLOAT, MPI_COMM_WORLD);
        //printf("Jsem proces [%d] a nasleduje vycet hodnot vsech vah od vsech procesu:\n",myid);
        int puv_weight = weight;
        int my_Val;
        if (myid == 0)
        {
            my_Val = 0;
        }    
        else
        {
            my_Val = all_weights[myid];
        }
        for (int i = 0; i <  log2 (2 * input.length()); i++)
        {
            succ_id = myid + pow(2,i);
            if(succ_id > (numprocs-1))
            {
                succ_id = numprocs-1;
            }
            
            
            weight = weight + all_weights[succ_id];

            MPI_Allgather(&weight, 1, MPI_FLOAT, &all_weights[0], 1, MPI_FLOAT, MPI_COMM_WORLD);
        }
        int final = input.length()*2 - weight + 1;
        MPI_Send(&puv_weight, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD);
        if(puv_weight == 1)
        {
            

            MPI_Send(&my_edge.second, 1, MPI_INT, 0, TAG, MPI_COMM_WORLD);

        }
        
        if (myid == 0)
        {
            char pre_order[numprocs];
            char geti='i';
            int its_weight;
            int cnt = 0;
            
            for (int i = 0; i < numprocs ; i++)
            {
                MPI_Recv(&its_weight, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &stat);

                 
                if(its_weight == 1)
                {
                    MPI_Recv(&geti, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &stat);
                    pre_order[cnt] = geti;
                    cnt++;
                }
                
        
                
            }
            printf("%c",input[0] );
            for (int i = 0; i < cnt; ++i)
            {
                printf("%c",pre_order[i] );
            }
            printf("\n");
           
            
        }

    MPI_Finalize(); 
    return 0;

 }
