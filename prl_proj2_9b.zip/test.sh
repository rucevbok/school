#!/bin/bash

if [ $# -lt 1 ];then 
    input='ABCDEFG';
else
    input=$1;
fi;

mpic++ --prefix /usr/local/share/OpenMPI -o pro pro.cpp

DELKA_VSTUPU=$(echo -n $input | wc -m)
b=$(( DELKA_VSTUPU + DELKA_VSTUPU - 2 ))

#vyrobeni souboru s random cisly
if [ $DELKA_VSTUPU -eq 1 ]
then
	echo $input
else

#spusteni
	mpirun --prefix /usr/local/share/OpenMPI -np $b pro $input

#uklid
	rm -f pro
fi