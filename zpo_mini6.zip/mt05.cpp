#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>



//  Funkce pro generování šumu typu pepř a sůl.
//  Parametr pokrytí udává, jaké procento pixelů v obraze bude šumem zkresleno a je v rozsahu 0.0-1.0.
void peprAsul( const cv::Mat& src, cv::Mat& dst, float pokryti )
{
    dst = src.clone();
    // Na náhodné pozice v obraze vygenerujte šum typu pepř a sůl.
    // Množství zašuměných pixelů musí odpovídat pokryti 
    /*  Working area - begin */
    cv::RNG rng;
    cv::Size s = src.size();
    int height = s.height;
    int width = s.width;
    int celkem_pixelu = height*width;

    //pocet zmenenych pixelu z obrazu, na zaklade velikost platna a procentu zmemenych
    int celkem_poskozenych = celkem_pixelu * pokryti; 
    for (int a = 0; a < celkem_poskozenych; a++)
    {
        // vygeneruju nahodne souradnice bodu zasazeneho sumem, generatorem s uniformnim rozdelenim
        int nahodne_x = rng.uniform (0, dst.rows);
        int nahodne_y = rng.uniform (0, dst.cols);
        int pepr_nebo_sul = rng.uniform (0, 255);
        
        // na zaklade vygenerovane hodnoty urcim zda bude pixel bily nebo cerny
        if (pepr_nebo_sul >= 127)
        {
            dst.at<unsigned char>(nahodne_x,nahodne_y) = 255;
        }
        else 
        {
            dst.at<unsigned char>(nahodne_x,nahodne_y) = 0;
        }          

    }
    /*  Working area - end */
}


//  Funkce pro filtraci obrazu pomocí mediánového filtru.
//     - velikost filtru v pixelech

void median( const cv::Mat& src, cv::Mat& dst, int velikost )
{
    // velikost - chceme liché číslo, minimálně 3
    int stred = velikost/2;
    stred = MAX(1,stred);
    velikost = 2*stred+1;
    
    // zvětšíme obraz a okopírujeme krajní hodnoty do okrajů
    cv::Mat srcBorder;
    copyMakeBorder( src, srcBorder, stred, stred, stred, stred, cv::BORDER_REPLICATE );

    // připravíme výstupní obraz
    dst = cv::Mat( src.size(), src.type() );

    // implementujte ručně mediánový filtr, výsledek uložte do výstupního obrazu dst
    // k řazení lze využít funkce std::sort()
    /*  Working area - begin */

    

    int cnt;
    std::vector<uchar> prome (velikost*velikost);
    int str = (velikost*velikost)/2;
    for(int i = 0; i < src.rows; i++)
    {
        for (int j = 0; j < src.cols; j++)
        {
            cnt = 0;
            for(int a = 0; a < velikost; a++)
            {
                for(int b = 0; b < velikost; b++)
                {
                    prome[cnt] = srcBorder.at<unsigned char>(i+a,j+b);
                    cnt++;
                }
            }
            std:sort(prome.begin(),prome.end());
            dst.at<unsigned char>(i,j) = prome[str];
        }
    }
    /*  Working area - end */

    return;
}



/* Vyhodnocení/porovnání výsledku s referenčním obrazem. */
void checkDifferences( const cv::Mat test, const cv::Mat ref, std::string tag, bool save = false);


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

//
// Examples of input parameters
// ./mt-05 ../../data/garden.png 0.05 7

int main(int argc, char* argv[])
{
    std::string img_path = "";
    float noise_amount = 0.05;
    int filter_size = 7;

    // check input parameters
    if( argc > 1 ) img_path = std::string( argv[1] );
    if( argc > 2 ) noise_amount = atof( argv[2] );
    if( argc > 3 ) filter_size = atoi( argv[3] );

    // load testing images
    cv::Mat src_rgb = cv::imread( img_path );

    // check testing images
    if( src_rgb.empty() ) {
        std::cout << "Failed to load image: " << img_path << std::endl;
        return -1;
    }

    cv::Mat src_gray;
    cv::cvtColor( src_rgb, src_gray, CV_BGR2GRAY );

    //---------------------------------------------------------------------------

    cv::Mat zasum, medi, medi_ref;

    peprAsul( src_gray, zasum, noise_amount );

    median( zasum, medi, filter_size );
    cv::medianBlur( zasum, medi_ref, filter_size );

    // vyhodnocení
    checkDifferences( zasum, src_gray, "05_noise", true );
    checkDifferences( medi,  medi_ref, "05_median", true );
    std::cout << std::endl;
    
    return 0;
}
//---------------------------------------------------------------------------




void checkDifferences( const cv::Mat test, const cv::Mat ref, std::string tag, bool save )
{
    double mav = 255., err = 255., nonzeros = 255.;
    cv::Mat diff;

    if( !test.empty() && !ref.empty() ) {
        cv::absdiff( test, ref, diff );
        cv::minMaxLoc( diff, NULL, &mav );
        err = ( cv::sum(diff).val[0] / (diff.rows*diff.cols) );
        nonzeros = 1. * cv::countNonZero( diff ) / (diff.rows*diff.cols);
    }
    
    if( save ) {
        if( !test.empty() ) { cv::imwrite( (tag+".png").c_str(), test ); }
        if( !diff.empty() ) { diff *= 255;  cv::imwrite( (tag+"_err.png").c_str(), diff ); }
    }

    printf( "%s %.2f %.2f %.2f ", tag.c_str(), err, nonzeros, mav );

    return;
}


