#!/usr/bin/python3

#CST:xvysta02

import getopt
import sys
import re
import os
import sys

#DODELAT rozpoznani ~ v argumentech
#FLAGY
flag_k=0
flag_o=0
flag_i=0
flag_c=0
flag_p=0
output_arg=""
sum_pattern=0
sum_keyword=0
sum_identifiers=0
sum_operators=0
cesty = []
pocty= []
vysledek=[]
count=0
nejdelsi=0
nejdelsi_l=0
nejdelsi_c=0
pattern_flag=0
flag_nosubdir=0
help_f=0
cfiles=""
input_arg=""

keys=["\\bauto\\b", "\\bbreak\\b", "\\bcase\\b", "\\bchar\\b", "\\bconst\\b", "\\bcontinue\\b", "\\bdefault\\b", "\\bdo\\b", "\\bdouble\\b", "\\belse\\b", "\\benum\\b", "\\bextern\\b", "\\bfloat\\b", "\\bfor\\b", "\\bgoto\\b", "\\bif\\b", "\\binline\\b", "\\bint\\b", "\\blong\\b", "\\bregister\\b", "\\brestrict\\b", "\\breturn\\b", "\\bshort\\b", "\\bsigned\\b", "\\bsizeof\\b", "\\bstatic\\b", "\\bstruct\\b", "\\bswitch\\b", "\\btypedef\\b", "\\bunion\\b", "\\bunsigned\\b", "\\bvoid", "\\bvolatile\\b", "\\bwhile\\b", "\\b_Bool\\b", "\\b_Complex\\b", "\\b_Imaginary\\b"]
operators=["\<\<\=","\>\>\=","->","\&\=","\^\=","\|=","\-\=","\+=","\%\=","\/=","\*=","\|\|","\&\&","\!=","==","\>\=","\<\=",">>","\<\<","\+\+","\-\-","\|","\+","\-","\*","\~","\!","\&","\/","\=","\^"]
suma=0


def help():
	print(" Napoved pro skript C Stats analyzujici .c a .h soubory, dle standardu ISO C99")
	print("Nasleduji parametry, ktere je mozno zadat")
	print("--help vytiskne tuto napovedu")
	print("--input=fileordir analyzuje zadany vstup, v pripade, ze se jedna o slozku, bude")
	print("analyzovana do hloubky dle zadanych parametru. V pripade, ze jde o soubor bude ")
	print("analyzovan. V pripade ze neni parametr zadan, vezme v potaz aktualni adresar.")
	print("--nosubdir prohleda pouze aktualni hladinu adresare, budto aktualni nebo zadany.")
	print("--output=filename vystupni soubor")
	print("-k vypise pocet vsech klicovych slov")
	print("-o vypise pocet vsech jednoduchych operatoru")
	print("-i vypise pocet vsech identifikatoru")
	print("-w=pattern vyhleda zadany textovy retezec pattern ve vsech zdrojovych kodech(da")
	print("-nych parametrem input")
	print("-c vypise pocet znaku vsech komentaru - jedno i viceradkovych")
	print("-p v kombinaci s prechozimi (az na help) zpusobi vypis souboru bez abs. cesty.")
	print("Jaroslav Vystavel, FIT 2BIT")


for i in range(1,len(sys.argv)):

	if re.search("(?<=input=).+", sys.argv[i]):
		input_arg = re.sub("--input=","",sys.argv[i])
		#print input_arg

	elif re.search("(?<=output=).+", sys.argv[i]):
		output_arg = re.sub("--output=","",sys.argv[i])
		#print output_arg

	elif re.search("(?<=w=).+", sys.argv[i]):
		pattern = re.sub("-w=","",sys.argv[i])
		pattern_flag=1
		#print pattern

	elif re.search("(--help)", sys.argv[i]):
		help_f=1

		#return 0


	elif sys.argv[i] == "--nosubdir":
		flag_nosubdir=1
		#print "je nastaveno nosubdir"


	elif sys.argv[i] == "-k":
		flag_k=1
		#print "je nastaveno k"

	elif sys.argv[i] == "-o":
		flag_o=1
		#print "je nastaveno o"	

	elif sys.argv[i] == "-i":
		flag_i=1
		#print "je nastaveno i"

	elif sys.argv[i] == "-c":
		flag_c=1
		#print "je nastaveno c"

	elif sys.argv[i] == "-p":
		flag_p=1
		#print "je nastaveno p"

	else:
		#print "lols"
		sys.stderr.write('Neplatny parametr')
		sys.exit(1)


if flag_k and flag_o:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_k and flag_i:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_k and pattern_flag:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_k and flag_c:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
###	
if flag_o and flag_k:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_o and flag_i:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_o and pattern_flag:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_o and flag_c:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
###
if flag_i and flag_k:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_i and flag_o:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_i and pattern_flag:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_i and flag_c:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
###
if pattern_flag and flag_k:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if pattern_flag and flag_o:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if pattern_flag and flag_i:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if pattern_flag and flag_c:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
###
if flag_c and flag_k:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_c and flag_o:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_c and flag_i:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)
if flag_c and pattern_flag:
	sys.stderr.write('Neplatny parametr')
	sys.exit(1)






if help_f:
	help()
	sys.exit(0)

if output_arg!="":
	try:
		fo = open(output_arg,"w")
	except IOError:
		sys.exit(3)






def readfile(file):
	global data
	with open(file, "r")  as myfile:

			data = myfile.read().replace("\r", "\n")
	#print data

def remove_comments():
	global data
	data=re.sub('//.*\n', '', data)
	data=re.sub('/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/', '', data)
	
	#print data

def remove_strings():
	global data
	data=re.sub('".*"', '', data)
	data=re.sub('\'.*\'', '', data)

def remove_macros():
	global data
	data=re.sub(r'#([\W\w\s\d])*?(\n.*?\\)*\n',"", data)


def count_keyword():
	global data, sum_keyword
	suma = 0
	for i in range(0,len(keys)):
		result = re.findall(keys[i], data)
		suma = suma +len(result)
		result = 0
	sum_keyword=suma+sum_keyword
	return suma
	#print "pocet klicovych slov: "+str(suma)

def count_operators():
	global data,sum_operators,cfiles
	suma = 0
	data=re.sub(r"\b(?:char|const|double|float|int|long|short|void|_Bool|_Complex)(?:\s*,?\s*\(?\s*\*+\s*\(?\w*\)?)+", "", data)

	for i in range(0,len(operators)):
		result = re.findall(operators[i], data)
		#if result:
			#print result
		data = re.sub(operators[i],"",data)
		suma = suma +len(result)
		result = 0
	sum_operators=suma+sum_operators
	return suma
	#print "pocet operatoru: "+str(suma)

def count_identifiers():
	
	global data,sum_identifiers
	suma = 0
	data=re.sub(r"\b(?:char|const|double|float|int|long|short|void|_Bool|_Complex)(?:\s*,?\s*\(?\s*\*+\s*\(?\w*\)?)+", "", data)
	
	for i in range(0,len(operators)):
		result = re.sub(operators[i],"", data)
	for i in range(0,len(keys)):
		result = re.sub(keys[i],"",result)
	#print result
	count = re.findall("\\b[_a-zA-Z][_0-9a-zA-Z]*\\b", result)
	#print "pocet indetifikatoru je: "  + str(len(count))
	sum_identifiers = len(count) + sum_identifiers
	return len(count)


def count_pattern(pattern):
	global data,sum_pattern
	suma = 0
	result = re.findall(pattern, data)
	suma = suma +len(result)
	sum_pattern=suma+sum_pattern
	return suma

def count_comments():
	global data, count
	act_count=0
	result = re.findall(r"(\/\*.*\*\/)|(//.*?\n)", data, re.DOTALL)

	for i in range(0,len(result)):
		for j in range(0,len(result[i])):
			act_count = act_count + len(result[i][j])
	
	count=act_count+count
	return act_count



def list_of_files():
	global cfiles,nejdelsi,nejdelsi_l,nejdelsi_c
	for root, dirs, files in os.walk(input_arg):
    		for name in files:
       			if name.endswith((".c",".h")):
            # whatever
				cfiles = [os.path.join(root, name)
            		for root, dirs, files in os.walk(input_arg)
            		for name in files
            		if name.endswith((".c",".h"))]
	#print cfiles
	if len(cfiles)==0:
		if output_arg=="":
			print "CELKEM: 0\n"
			sys.exit(0)
    		fo = open(output_arg,"w")
		fo.write("CELKEM: 0\n")
		sys.exit(0)


    	#cfiles.sort()
	#print cfiles
	for i in range(0,len(cfiles)):
		#print cfiles[i]
		readfile(cfiles[i])

		if pattern_flag:
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_pattern(pattern)))

			#print sum_pattern

		if flag_k:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_keyword()))
			#print sum_keyword

		if flag_i:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_identifiers()))
			#print sum_identifiers

		if flag_o:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_operators()))
			#print sum_operators

		if flag_c:
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_comments()))			
			#print count

	if pattern_flag:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()

		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_pattern))
			print("CELKEM"+pocet_mezer*" "+str(sum_pattern))
			sys.exit(0)

		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_pattern))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_pattern)+"\n")
		#print "celkem shod : " + str(sum_pattern)
	if flag_k:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()

		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_keyword))
			print("CELKEM"+pocet_mezer*" "+str(sum_keyword))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_keyword))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_keyword)+"\n")
	if flag_i:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_identifiers))
			print("CELKEM"+pocet_mezer*" "+str(sum_identifiers))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_identifiers))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_identifiers)+"\n")
		
	if flag_o:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_operators))
			print("CELKEM"+pocet_mezer*" "+str(sum_operators))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_operators))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_operators)+"\n")
	if flag_c:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(count))
			print("CELKEM"+pocet_mezer*" "+str(count))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(count))
		fo.write("CELKEM"+pocet_mezer*" "+str(count)+"\n")
		#print "celkem komentu: " + str(count)		

def files_in_directory():	
	global cfiles, pattern_flag, sum_pattern,sum_keyword,sum_identifiers,sum_operators,nejdelsi_c,nejdelsi_l,count,suma
	for files in os.listdir(input_arg):
   		if files.endswith((".c",".h")):
        		cfiles = [os.path.join(files)
            		for files in os.listdir(input_arg)
    					if files.endswith((".c",".h"))]
	for i in range(0,len(cfiles)):
		cfiles[i]=os.getcwd()+"/"+ cfiles[i]
		readfile(cfiles[i])

		if pattern_flag:
			#print os.getcwd()+"/"+cfiles[i]
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_pattern(pattern)))
			
			#print sum_pattern

		if flag_k:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_keyword()))
			#print sum_keyword

		if flag_i:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_identifiers()))
			#print sum_identifiers

		if flag_o:
			remove_comments()
			remove_strings()
			remove_macros()
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_operators()))
			#print sum_operators

		if flag_c:
			
			if flag_p:
				cesty.append(os.path.basename(cfiles[i]))	
			else:
				cesty.append(cfiles[i])
			pocty.append(str(count_comments()))
			#print count

	if pattern_flag:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_pattern))
			print("CELKEM"+pocet_mezer*" "+str(sum_pattern))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_pattern))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_pattern)+"\n")
		#print "celkem shod : " + str(sum_pattern)
	if flag_k:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_keyword))
			print("CELKEM"+pocet_mezer*" "+str(sum_keyword))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_keyword))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_keyword)+"\n")
		
	if flag_i:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_identifiers))
			print("CELKEM"+pocet_mezer*" "+str(sum_identifiers))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_identifiers))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_identifiers)+"\n")
		
	if flag_o:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_operators))
			print("CELKEM"+pocet_mezer*" "+str(sum_operators))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_operators))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_operators)+"\n")

	if flag_c:
		#print sum_operators
		#print len(cesty)
		for i in range(0,len(cesty)):
			if nejdelsi_c<len(cesty[i]):
				nejdelsi_c=len(cesty[i])
		for i in range(0,len(pocty)):
			if nejdelsi_l<len(pocty[i]):
				nejdelsi_l=len(pocty[i])
		delka=nejdelsi_l+nejdelsi_c+1
		for i in range(0,len(cesty)):
			pocet_mezer=delka-len(cesty[i])-len(pocty[i])
			out=cesty[i]+ pocet_mezer*" " + pocty[i]
			vysledek.append(out)
		#print len(pocty)
		vysledek.sort()
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(count))
			print("CELKEM"+pocet_mezer*" "+str(count))
			sys.exit(0)
		fo = open(output_arg,"w")
		for i in range(0,len(vysledek)):
			fo.write(vysledek[i])
			fo.write("\n")
		pocet_mezer=delka-6-len(str(count))
		fo.write("CELKEM"+pocet_mezer*" "+str(count)+"\n")




##################################MAIN
#print input_arg

if input_arg == "":
	input_arg = os.getcwd()
	if flag_nosubdir:
		files_in_directory()
	else:
		list_of_files()


elif os.path.isdir(input_arg):
	
	if flag_nosubdir:
		files_in_directory()
	else:
		
		list_of_files()

elif os.path.isfile(input_arg):
	if flag_nosubdir:
		sys.stderr.write('chyba! nesmi byt nastaveno nosubdir a konkretni soubor')
		sys.exit(1)
	
	

	readfile(input_arg)

	if pattern_flag:
		if flag_p:
			cesty.append(os.path.basename(input_arg))	
		else:
			cesty.append(input_arg)
		pocty.append(str(count_pattern(pattern)))
		#print sum_pattern

	if flag_k:
		remove_comments()
		remove_strings()
		remove_macros()
		if flag_p:
			cesty.append(os.path.basename(input_arg))	
		else:
			cesty.append(input_arg)
		pocty.append(str(count_keyword()))
		#print sum_keyword

	if flag_i:
		remove_comments()
		remove_strings()
		remove_macros()
		if flag_p:
			cesty.append(os.path.basename(input_arg))	
		else:
			cesty.append(input_arg)
		pocty.append(str(count_identifiers()))
			#print sum_identifiers

	if flag_o:
		remove_comments()
		remove_strings()
		remove_macros()
		if flag_p:
			cesty.append(os.path.basename(input_arg))	
		else:
			cesty.append(input_arg)
		pocty.append(str(count_operators()))
		#print sum_operators

	if flag_c:
		if flag_p:
			cesty.append(os.path.basename(input_arg))	
		else:
			cesty.append(input_arg)
		pocty.append(str(count_comments()))
			#print count

	if pattern_flag:
	
		delka=len(cesty[0]) + len(str(pocty[0]))+1
		vysledek.append(cesty[0] + " " + pocty[0])
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_pattern))
			print("CELKEM"+pocet_mezer*" "+str(sum_pattern))
			sys.exit(0) 
		fo = open(output_arg,"w")
		fo.write(vysledek[0])
		fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_pattern))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_pattern)+"\n")
		#print "celkem shod : " + str(sum_pattern)
	if flag_k:
		delka=len(cesty[0]) + len(str(pocty[0]))+1
		vysledek.append(cesty[0] + " " + pocty[0]) 
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_keyword))
			print("CELKEM"+pocet_mezer*" "+str(sum_keyword))
			sys.exit(0)
		fo = open(output_arg,"w")
		fo.write(vysledek[0])
		fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_keyword))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_keyword)+"\n")
		#print "celkem klicovych slov: " + str(sum_keyword)

	if flag_i:
		delka=len(cesty[0]) + len(str(pocty[0]))+1
		vysledek.append(cesty[0] + " " + pocty[0]) 
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_identifiers))
			print("CELKEM"+pocet_mezer*" "+str(sum_identifiers))
			sys.exit(0)
		fo = open(output_arg,"w")
		fo.write(vysledek[0])
		fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_identifiers))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_identifiers)+"\n")
		#print "celkem identifikatoru: " + str(sum_identifiers)

	if flag_o:
		delka=len(cesty[0]) + len(str(pocty[0]))+1
		vysledek.append(cesty[0] + " " + pocty[0]) 
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(sum_operators))
			print("CELKEM"+pocet_mezer*" "+str(sum_operators))
			sys.exit(0)
		fo = open(output_arg,"w")
		fo.write(vysledek[0])
		fo.write("\n")
		pocet_mezer=delka-6-len(str(sum_operators))
		fo.write("CELKEM"+pocet_mezer*" "+str(sum_operators)+"\n")
		#print "celkem operatoru :" + str(sum_operators)
	if flag_c:
		delka=len(cesty[0]) + len(str(pocty[0]))+1
		vysledek.append(cesty[0] + " " + pocty[0]) 
		if output_arg=="":
			for i in range(0,len(vysledek)):
				print(vysledek[i])

			pocet_mezer=delka-6-len(str(count))
			print("CELKEM"+pocet_mezer*" "+str(count))
			sys.exit(0)
		fo = open(output_arg,"w")
		fo.write(vysledek[0])
		fo.write("\n")
		pocet_mezer=delka-6-len(str(count))
		fo.write("CELKEM"+pocet_mezer*" "+str(count)+"\n")
		#print "celkem komentu: " + str(count)	

else:
	sys.stderr.write('nelze otevrit vstupni soubor')
	sys.exit(2)







