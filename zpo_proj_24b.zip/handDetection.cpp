/* 
 * ZPO Detekce a sledování rukou ve videu
 * Autor: Tomáš Hynek (xhynek09), Jaroslav Vystavěl (xvysta02)
 * Letní semestr 2017/2018
 */

#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <algorithm>
#include <iostream>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <stdlib.h>
#include <math.h>
#include <fstream>
#include "opencv2/core/utility.hpp"
#include <opencv2/features2d.hpp>
#include "opencv2/video/tracking.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/objdetect/objdetect.hpp"

#include <sys/types.h>
#include <dirent.h>

#include <cv.h>
#include "cvaux.h"
#include "cxmisc.h"
#include <ctype.h>

using namespace cv;
using namespace std;

int counHist = 0;
bool showAllContours = false;
int minNumOfFingers = 1;
bool turnOnFaceDetect = true;
bool showBackProjection = false;
bool setResizeWindow = false;

// Zobrazení Histogramu
Mat printHistogram(Mat hist) {
    int hist_w = 1024; int hist_h = 720;
    int histSize = 256;
    int bin_w = cvRound((double) hist_w/histSize);
    Mat histImage(hist_h, hist_w, CV_8UC3, Scalar( 0,0,0));

    for( int i = 0; i < histSize; i++) {
        line(histImage,
            Point( bin_w*(i-1), hist_h - cvRound(hist.at<float>(i-1))),
            Point( bin_w*(i), hist_h - cvRound(hist.at<float>(i))),
            Scalar(0, 255, 0), 2, 8, 0);
    }

    return histImage;
}

float innerAngle(float px1, float py1, float px2, float py2, float cx1, float cy1) {
    // pythagorova věta
    float dist1 = sqrt((px1-cx1) * (px1-cx1) + (py1-cy1) * (py1-cy1));
    float dist2 = sqrt((px2-cx1) * (px2-cx1) + (py2-cy1) * (py2-cy1));

    float Ax, Ay;
    float Bx, By;
    float Cx, Cy;

    Cx = cx1;
    Cy = cy1;

    if(dist1 < dist2) {
        Bx = px1;
        By = py1;
        Ax = px2;
        Ay = py2;
    } else {
        Bx = px2;
        By = py2;
        Ax = px1;
        Ay = py1;
    }

    float Q1 = Cx - Ax;
    float Q2 = Cy - Ay;
    float P1 = Bx - Ax;
    float P2 = By - Ay;

    // arcos(x . y / |x||y|)
    float A = acos( (P1*Q1 + P2*Q2) / ( sqrt(P1*P1+P2*P2) * sqrt(Q1*Q1+Q2*Q2)));

    A = A * 180 / CV_PI;

    return A;
}

/* Detekce prstů na základě délky a úhlů */
int getFingerValley(vector<Point> contour, Mat frame) {
    // najde konvexní obálku pro contour
    vector<vector<Point> > hull(1);
    convexHull(Mat(contour), hull[0], false);
    
    // obálku ohraničí obdélníkem
    Rect boundingBox = boundingRect(hull[0]);
    // možnost vykreslení kontur
    if (showAllContours) {
        drawContours(frame, hull, 0, Scalar(0, 255, 0), 3);
        rectangle(frame, boundingBox, Scalar(255, 0, 0));
    }
    
    // centrální bod konvexní obálky (resp. obdélníku)
    Point centroid = Point(boundingBox.x + boundingBox.width / 2, boundingBox.y + boundingBox.height / 2);
    if (showAllContours) {
        circle(frame, centroid, 9, Scalar(0, 255, 255), 2);
    }
    vector<Point> fingerPoints;

    double minLength = 0.1 * boundingBox.height;

    // pokud existují alespoň dve čáry jdoucí z jednoho prstu
    if (hull[0].size() > 2) {
        vector<int> hullIndexes;
        convexHull(Mat(contour), hullIndexes, true);
        vector<Vec4i> convexDefects;
        convexityDefects(Mat(contour), hullIndexes, convexDefects);
        
        // pro každý convexDefect si uloží do proměnné typu Point počáteční, koncový a středový bod
        for (size_t i = 0; i < convexDefects.size(); i++) {
            Point startPoint = contour[convexDefects[i][0]];
            Point endPoint = contour[convexDefects[i][1]];
            Point middlePoint = contour[convexDefects[i][2]];
            
            if (showAllContours) {
                line(frame, startPoint, middlePoint, Scalar(255, 0, 0), 2);
                line(frame, middlePoint, endPoint, Scalar(255, 0, 0), 2);
            }

            // úhel "na špičce prstu" - inverzní funkce tangens
            double angle = atan2(centroid.y - startPoint.y, centroid.x - startPoint.x) * 180 / CV_PI;
            // vnitřní úhel (mezi prsty)
            double innnerAngle = abs(innerAngle(startPoint.x, startPoint.y, endPoint.x, endPoint.y, middlePoint.x, middlePoint.y));
            // délka prstu 
            double length = sqrt(pow(startPoint.x - middlePoint.x, 2) + pow(startPoint.y - middlePoint.y, 2));

            // vyhodnocení, zda se jedná o prst, či nikoliv
            if (angle > -30 && angle < 180 && innnerAngle > 20 && innnerAngle < 160 && length > minLength) {
                fingerPoints.push_back(startPoint);
            }
        }
        
        // vykreslí kruh na konci detekovaného prstu
        if (showAllContours) {
            for (size_t i = 0; i < fingerPoints.size(); i++) {
                circle(frame, fingerPoints[i], 9, Scalar(0, 255, 0), 2);
            }        
        }
    }

    return fingerPoints.size();
}

bool detectFace(Mat frame) {
    // haarovy příznaky pro obličej a pro oči
    String faceCascadeName = "db/haarcascade_frontalface.xml";
    String eyeCascadeName = "db/haarcascade_eye.xml";
    CascadeClassifier faceCascade = CascadeClassifier(faceCascadeName);
    CascadeClassifier eyesCascade = CascadeClassifier(eyeCascadeName);

    // vektor obdélníků ohraničujících obličeje
    vector<Rect> faces;
    Mat frame_gray;

    cvtColor(frame, frame_gray, COLOR_BGR2GRAY);
    equalizeHist(frame_gray, frame_gray);

    // detekuje obličeje na základě haarových příznaků, výsledek je ve faces
    faceCascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0|CASCADE_SCALE_IMAGE, Size(60, 60));

    // pro každý obličej
    for (size_t i = 0; i < faces.size(); i++) {
        // stanoví středový bod
        Point center(faces[i].x + faces[i].width/2, faces[i].y + faces[i].height/2);

        // eventuelně zvýrazní obličej elipsou
        if (showAllContours) {
            ellipse(frame, center, Size(faces[i].width/2, faces[i].height/2), 0, 0, 360, Scalar(255,0,255), 4, 8, 0);
        }

        // vytvoří matici obsahující detekované obličeje
        Mat faceROI = frame_gray( faces[i] );
        vector<Rect> eyes;

        // detekce očí, výstupem je vektor obdélníků, kde každý obsahuje zdetekované oko
        eyesCascade.detectMultiScale(faceROI, eyes, 1.1, 2, 0 |CASCADE_SCALE_IMAGE, Size(30, 30));

        // pro každé detekované oko
        for (size_t j = 0; j < eyes.size(); j++) {
            // najde geometrický střed oko
            Point eye_center(faces[i].x + eyes[j].x + eyes[j].width / 2, faces[i].y + eyes[j].y + eyes[j].height / 2);
            int radius = cvRound((eyes[j].width + eyes[j].height) * 0.25);

            // kruhem zvýrazní každé oko
            if (showAllContours) {
                circle(frame, eye_center, radius, Scalar(255,255,0), 4, 8, 0);
            }
        }

        if (eyes.size() > 0) {
            return true;
        }
    }

    return false;
}

void detectHand(Mat frame, Mat& hueModelHist) {
    Mat imageHSV, hue, mask, hist, backproj;

    // převod snímku z kamery do HSV
    cvtColor(frame, imageHSV, COLOR_BGR2HSV);
    
    // metoda prahování pro rozsah hodnot v HSV
    inRange(imageHSV, Scalar(0, 60, 32), Scalar(25, 255, 255), mask);
    
    // morfologické operace, snížení šumu a rozmazání ostrých kontur
    erode(mask, mask, Mat(), Point(-1,-1), 1, 1, 1);
    dilate(mask, mask, 0, Point(-1, -1), 5, 1, 1);

    // matice hue obsahuje kanál H z půvdoního obrázku
    int ch[] = {0, 0};
    hue.create(imageHSV.size(), imageHSV.depth());
    mixChannels(&imageHSV, 1, &hue, 1, ch, 1);

    // bins histogramu
    float hranges[] = {0,180};
    const float* phranges = hranges;

    // vypočítá back projection z hue na základě histogramu hueModelHist
    calcBackProject(&hue, 1, 0, hueModelHist, backproj, &phranges);
    
    if (showBackProjection) {
        imshow("CalcBackProject First", backproj);
        imshow("mask", mask);
    }
    
    backproj &= mask;

    if (showBackProjection) {
        imshow("CalcBackProject After Mask", backproj);
    }

    // morfologické operace, snížení šumu a rozmazání ostrých kontur
    erode(backproj, backproj, Mat(), Point(-1,-1), 1, 1, 1);
    dilate(backproj, backproj, 0, Point(-1, -1), 5, 1, 1);

    if (showBackProjection) {
        imshow("CalcBackProject After Erode and Dilate", backproj);
    }

    // vektor kontur
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    // detekce kontur pomocí vestavěné funkce
    findContours(backproj, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

    bool isItFace;              // flag pro detekci obličeje
    int numOfFingers = 0;       // proměnná vyjadřující počet detekovaných prstů
    Rect trackWindow;           // obdélník oblasti zájmu

    // cyklus procházející všechny nalezené kontury
    for (int i = 0; i < contours.size(); i++) {
        // pokud má kontura více než 10000 pixelů, tak nás dále zajímá     
        if (contourArea(contours[i]) > 10000) {
            // implicitně nastavíme, že se nejedná o obličej
            isItFace = false;
            // počet detekovaných prstů v kontuře
            numOfFingers = getFingerValley(contours[i], frame);

            // pokud je nastaven flag pro vykreslení kontur nebo jsou detekovány prsty
            if (showAllContours || numOfFingers >= minNumOfFingers) {
                Rect boundRect = boundingRect(Mat(contours[i]));    // ohraničení kontury obdélníkem
                Point startPoint = boundRect.tl();                  // levý horní roh
                Point endPoint = boundRect.br();                    // pravý horní roh

                // nastavení rozměrů a počátečních bodů 
                trackWindow.x = startPoint.x;
                trackWindow.y = startPoint.y;
                trackWindow.width = abs(endPoint.x - startPoint.x);
                trackWindow.height = abs(endPoint.y - startPoint.y);

                if (turnOnFaceDetect) {
                    Mat cropImage = frame(boundRect);
                    isItFace = detectFace(cropImage);   // detekce obličeje a očí
                }

                // pokud to není obličej, detekuj ruku
                if (!isItFace) {
                    // provedení camshift metody
                    RotatedRect trackBox = CamShift(backproj, trackWindow, TermCriteria(TermCriteria::EPS | TermCriteria::EPS, 10, 1));
                    // orámování výstupu camshiftu elipsou
                    ellipse(frame, trackBox, Scalar(0,0,255), 3, LINE_AA);
                }
            }
        }
    }

    if (setResizeWindow) {
        resize(frame, frame, Size(frame.cols/1.5, frame.rows/1.5));
    }

    namedWindow("Hand Detection", CV_WINDOW_AUTOSIZE);
    imshow("Hand Detection", frame);
}

// funkce pro získání modelu histogramu odpovídajícího snímkům
Mat getModels() {
    const int numOfFiles = 21;
    // databáze fotek
    string fileName[numOfFiles] = 
        {"db/hand01.png", 
         "db/hand02.png", 
         "db/hand03.png", 
         "db/hand04.png", 
         "db/hand05.png", 
         "db/hand06.png", 
         "db/hand07.png", 
         "db/hand08.png", 
         "db/hand09.png", 
         "db/hand10.png",
         "db/hand11.png", 
         "db/hand12.png", 
         "db/hand13.png", 
         "db/hand14.png", 
         "db/hand15.png",
         "db/hand16.png", 
         "db/hand17.png", 
         "db/hand18.png", 
         "db/hand19.png",
         "db/hand20.png",
         "db/hand21.png"
     };

    int histHeight = 720;                           // šířka histogramu
    Mat hueModel = Mat::zeros(256, 1, CV_32F);      // inicializace matice
    int histSize = 256;
    bool uniform = true; bool accumulate = false;

    // načtení všech souborů s fotkami
    for(int pos = 0; pos < numOfFiles; pos++) {
        cout << fileName[pos] << endl;
        Mat src = imread(fileName[pos], 1);   // Input image

        if(!src.data)
            throw "\033[1;31mERROR: when reading hand image\033[0m\n";

        Mat imageHSV, mask, hue, hist;
        cvtColor(src, imageHSV, COLOR_BGR2HSV);     // převod obrázku do modelu HSV

        // tresholding, parametry byly zvoleny testováním
        inRange(imageHSV, Scalar(0, 60, 32), Scalar(25, 255, 255), mask);
    
        int ch[] = {0, 0};
        hue.create(imageHSV.size(), imageHSV.depth());      // vytvoří matici se stejnými parametry jako imageHSV
        mixChannels(&imageHSV, 1, &hue, 1, ch, 1);          // výber hue kanálu

        float hranges[] = {0,180};
        const float* phranges = hranges;

        // výpočet histogramu z matice a jeho následná normalizace
        calcHist(&hue, 1, 0, mask, hist, 1, &histSize, &phranges, uniform, accumulate);
        normalize(hist, hist, 0, histHeight, NORM_MINMAX);  
        add(hueModel, hist, hueModel);      // přičtení histogramu aktuálního obrázku do sumy histogramů
    }

    normalize(hueModel, hueModel, 0, histHeight, NORM_MINMAX, -1, Mat());
    
    Mat histImage = printHistogram(hueModel);

    namedWindow("Histogram of Hue Model", CV_WINDOW_AUTOSIZE);
    imshow("Histogram of Hue Model", histImage);

    return hueModel;
}

static void printHelp() {
    string hot_keys =
    "\nHot keys: \n"
    "\tESC - quit the program\n"
    "\tc - show/hide all detected contours and shapes\n"
    "\tb - start/stop backprojection view\n"
    "\th - start/stop face detection\n"
    "\tr - maximaze/minimaze hadnDetectin window\n\n"
    "Legends:\n"
    "\tred - detected hand by camshfit\n"
    "\tblue - convexityDefects from contour\n"
    "\tgreen - convexHull from contour\n"
    "\tgreen circle - finger point\n"
    "\tyellow circle - contour/hand centroid\n"
    "\tpurple circle - face detection\n"
    "\tteal circle - eyes detection\n"
    "\tblue rectangle - boundingBox of contour\n\n"

    ;
    cout << hot_keys;
}

/* ********************************************************************** */
/* ******************************  MAIN  ******************************** */
int main(int argc, char** argv) {
    printHelp();        // tisk nápovědy aplikace

    // model histogramu
    Mat hueModel;
    hueModel = getModels();

    Mat cameraFrame;
    VideoCapture capture(0);
    if(!capture.isOpened())
        throw "\033[1;31mERROR: when reading camera stream\033[0m\n";

    while (true) {
        // načítání snímků kamery
        capture.read(cameraFrame);

        if(cameraFrame.empty())
            break;

        // detekování ruky na základě modelu histogramu
        detectHand(cameraFrame, hueModel);        

        char c = (char)waitKey(10);
        if (c == 27)
            break;
        switch(c) {
            case 'c':
                if (showAllContours) {
                    showAllContours = false;
                } else {
                    showAllContours = true;
                }
                break;
            case 'h':
                if (turnOnFaceDetect) {
                    turnOnFaceDetect = false;
                } else {
                    turnOnFaceDetect = true;
                }
                break;
            case 'b':
                if (showBackProjection) {
                    showBackProjection = false;
                } else {
                    showBackProjection = true;
                }
                break;
            case 'r':
                if (setResizeWindow) {
                    setResizeWindow = false;
                } else {
                    setResizeWindow = true;
                }
                break;
            default:
                ;
        }
    }

    return 0;
}